# mwss
This is the source code for the "mwss" package in R. This package allows the user to run multi-ward stocahstic simulations to simulate virus transmission in the hospital setting.

You should be able to install this using the following R code: library(devtools); install_github("ajmalo/mwss").
