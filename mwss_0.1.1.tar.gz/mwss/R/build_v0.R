#' Build and initialize v0
#'
#' @description
#'
#' @usage build_v0()
#'
#' @return Matrix Empty v0 matrix to store weighted proportion of infected in 3 subpopulations at each time step
#'

build_v0 <- function(u0, SA){

  if(isTRUE(SA)){
    cols <- c("wpropInfHorig", "wpropInfHdest", "wpropInfPSAdest", "wpropInfPWdest",
              rbind(paste0("nadm", seq(nrow(u0))),
                    paste0("nadmInf", seq(nrow(u0)))))

    v0 <- matrix(data = 0,
                 nrow = nrow(u0),
                 ncol = length(cols),
                 dimnames = list(NULL, cols))

    } else
                   v0 <- matrix(data = 0,
                                nrow = nrow(u0),
                                ncol = 3L,
                                dimnames = list(NULL, c("wpropInfHorig", "wpropInfHdest", "wpropInfPWdest")))

  v0 %<>% data.frame

  return(v0)
}
