#' FIX ME
#'
#' @description \code{timeShare} returns FIX ME
#'
#' @param contacts FIX ME
#' @param namesincol1 FIX ME
#'
#' @return FIX ME
#'
#' @export


timeShare <- function(contacts, namesincol1 = TRUE){

  if(isTRUE(namesincol1)){
    rownames(contacts) <- contacts[,1]
    contacts <- contacts[,-1]
  }

  wards <- rownames(contacts)
  HCWSs <- colnames(contacts)
  nwards <- length(wards)



  # Each HCWS is affiliated to the ward where it spend more time
  affiliation <- sapply(HCWSs, function(HCWS)
    contacts[,HCWS] %>% which.max %>% wards[.]
    )

  contactMat <- lapply(wards, function(WD){
    nconnect <- HCWSs[affiliation == WD] %>% length

    if(nconnect == 0)
      return(rep(0, nwards))

    if(nconnect == 1)
    return(contacts[, HCWSs[affiliation == WD]] %>% divide_by(sum(.)) %>% round(.,2))

    if(length(HCWSs[affiliation == WD]) > 1)
    return(contacts[, HCWSs[affiliation == WD]] %>% rowMeans %>% round(., 2))

  }) %>% do.call(rbind, .)

  rownames(contactMat) <- colnames(contactMat) <- wards

  return(contactMat)
}

