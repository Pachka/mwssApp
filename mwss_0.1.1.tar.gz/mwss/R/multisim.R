#' Generate multiple trajectories
#'
#' @description \code{multisim} returns
#'
#' @usage multisim()
#'
#' @param model SimInf model
#' @param nSim number of simulations
#' @param ward_names string vector with ward names/id

#' @return list of list

#' @examples
#'
#' @export


multisim <- function(model, nSim, ward_names){

  if(shiny::isRunning())
    withProgress(
      message = 'Simulations in progress',
      detail = 'This may take a while...',
      style = getShinyOption("progress.style", default = "notification"),{

        trajmwss <- lapply(1:nSim, function(x){
          result <- trajectory(run(model))
          result %<>% as.data.table
          incProgress(1/nSim)
          result[, node := ward_names[node]]
        })

      }) else
        trajmwss <- lapply(1:nSim, function(x){
          result <- trajectory(run(model))
          result %<>% as.data.table
          result[, node := ward_names[node]]
        })

  class(trajmwss) <- "mwss"
  return(trajmwss)
  }
