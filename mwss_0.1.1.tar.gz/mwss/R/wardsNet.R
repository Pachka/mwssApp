#' Produce the network
#'
#' @description \code{wardsNet} returns an igraph object ready to be plotted with individual editing
#' (refer to igraph package or https://igraph.org/r/doc/plot.common.html).
#' The function also returns a generic png plot. Wards are reprensented
#' according to the patient population size. Connexion between size depends on values in the contact matrix.
#'
#' @usage wardsNet(matContact, size)
#'
#' @param connexions Matrix reporting  the proportion of time spent by health care workers in the different wards.
#' @param size Vector of population size in each ward (beds, HCWS or sum of both).
#' @param edgewidthrate Integer, proportional coefficient to adjust edge width.

wardsNet <- function(connexions, size, edgewidthrate){

  if(sum(connexions$nHCWS!=0) > 0){

    connexions %<>% .[.$nHCWS!=0, ]

    g <- graph_from_data_frame(connexions, directed = TRUE, vertices = data.frame(name = names(size), size = size))

    E(g)$weight <- connexions$nHCWS %<>% divide_by(max(.)) %>% multiply_by(edgewidthrate)

    g %<>% intergraph::asNetwork(.)

  } else {
    num_nodes <- length(size)
    my_sociomatrix <- matrix(rep(0, num_nodes * num_nodes),
                             # edge values
                             nrow = num_nodes,
                             #nrow must be same as ncol
                             ncol = num_nodes)

    diag(my_sociomatrix) <- 0

    g <- as.network(
      x = my_sociomatrix,
      # the network object
      directed = TRUE,
      # specify whether the network is directed
      loops = FALSE,
      # do we allow self ties (should not allow them)
      matrix.type = "adjacency" # the type of input
    )

    network::set.vertex.attribute(g, "vertex.names", connexions$from_ward)

  }

  return(g)
}

