#' Generate simulations
#'
#' @description \code{mwss} returns
#'
#' @usage mwss()
#'
#' @param ward_names vector of wards names with the associated numbers of beds and health care workers.
#' @param pop_size_P Vector of numbers of beds per ward.
#' @param pop_size_H Vector of numbers of health care workers per ward.
#' @param nVisits Vector of average numbers of visits per ward per day.
#' @param LS Vector of average length of stay per ward in days.
#' @param matContact matrix of contact. Each row gives proportion of time spent by HW from a ward in all wards (columns). Wards order in rows and columns must be identical to ward_names vector. Rows sum should be equal to 1.
#' @param IMMstate data.frame describing the immunity levels of patients and healthcare workers. Default is NULL (all individuals are considered non immunized). (FIX ME: describe data.table)
#' @param EPIstate data.frame describing the epidemiological states of patients and healthcare workers.  Default is NULL (all individuals are considered susceptible). (FIX ME: describe data.table)
#' @param SA logical. Contact are restricted at the admission. Default is FALSE.
#' @param nH_SA Vector of number of health care workers in charge of admissions in the screening area at the admission (clinical examination/test).
#' @param test logical. Tested compartment are added to the epidemiological compartments. Default is FALSE.
#' @param gdata named numeric vector or one-row data.frame describing global parameters. (see ? SimInf::mparse)
#' @param tspan integer or date vector listing time points where the state of each node has to be returned (see ? SimInf::mparse)
#' @param verbose logical used to display or shut down warnings.
#'
#' @return List of list. Each list correspond to a simulation. Each list contain one matrix per ward. Each matrix contain the daily simulated population vectors.
#' @examples
#'
#' @export


mwss <- function(ward_names,
                 pop_size_P,
                 pop_size_H,
                 nVisits,
                 LS,
                 matContact = NULL,
                 IMMstate = NULL,
                 EPIstate = NULL,
                 SA = FALSE,
                 nH_SA = NULL,
                 gdata,
                 tspan =  1:365,
                 verbose = TRUE){

  # run startvec
  xstart <- startvec(ward_names = ward_names,
                     pop_size_P = pop_size_P,
                     pop_size_H = pop_size_H,
                     nVisits = nVisits,
                     LS = LS,
                     matContact = matContact,
                     IMMstate = IMMstate,
                     EPIstate = EPIstate,
                     SA = SA,
                     nH_SA = nH_SA,
                     verbose = verbose)

  ### Build u0
  u0 <- xstart$u0

  ### Build ldata
  # A numeric matrix with local data specific to each node. The column ldata[, j]
  # contains the local data vector for node j. The local data vector is passed as an argument
  # to the transition rate functions and the post time step function.

  ldata <- xstart$ldata

  v0 <- build_v0(u0, SA)

  pts_fun <- build_pts_fun(u0, SA, v0)

  transitions <- build_transitions(SA)

  compartments <- colnames(u0)

  E <- build_E(compartments)

model <- mparse(
  transitions = transitions,
  compartments = compartments,
  ldata = ldata,
  gdata = gdata,
  u0 = u0,
  v0 = v0,
  tspan = tspan,
  events = NULL,
  E = E,
  N = NULL,
  pts_fun = pts_fun
)

return(model)
}
