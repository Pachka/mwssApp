#' Design initial population vectors
#'
#' @description \code{startvec} returns a table with initial epidemiological states of the population in the wards. By default all patients and healthcare workers are susceptible.
#' Other epidemiological states can be speficied using 'introduction'.
#'
#' @param ward_names vector of wards names with the associated numbers of beds and health care workers.
#' @param pop_size_P Vector of numbers of beds per ward.
#' @param pop_size_H Vector of numbers of health care workers per ward.
#' @param nVisits Vector of average numbers of visits per ward per day.
#' @param LS Vector of average length of stay per ward in days.
#' @param matContact matrix of contact. Each row gives proportion of time spent by HW from a ward in all wards (columns). Wards order in rows and columns must be identical to ward_names vector. Rows sum should be equal to 1.
#' @param IMMstate data.frame describing the immunity levels of patients and healthcare workers. Default is NULL (all individuals are considered non immunized). (FIX ME: describe data.table)
#' @param EPIstate data.frame describing the epidemiological states of patients and healthcare workers.  Default is NULL (all individuals are considered susceptible). (FIX ME: describe data.table)
#' @param SA logical. Contact are restricted at the admission. Default is FALSE.
#' @param nH_SA Vector of number of health care workers in charge of "admissions in the screening area at the admission (clinical examination/test).
#' @param verbose logical used to display or shut down warnings.
#'
#' @importFrom data.table setDT
#' @importFrom magrittr '%<>%'
#'
#' @return List of two objects: u0, a data.frame of initial demographic and epidemiological state of the population, and ldata: matrix with local parameters.
#' ldata contains `nP` the number of beds in each ward, `nVisit` the average number of visit per patient per day,`tS` the average length of stay in each ward
#'
#' @examples
#' nwards <- 5
#' ward_names <- letters[1:nwards]
#' pop_size_P <- rep(20,nwards)
#' pop_size_H <- rep(15,nwards)
#' nVisits <- rep(0,nwards)
#' LS <- rep(0.05,nwards)
#' matContact <-randomContacts(pop_size_H, ward_names)$contactMat
#'
#' IMMstate <- data.frame(
#' ward = c("a", "c", "b"),
#' pop = c("P","P", "H"),
#' imm = c("LI", "HI", "HI"),
#' n = c(3, 2, 10)
#' )
#' EPIstate <- data.frame(ward = c("b", "d"),
#' pop = c("P","H"),
#' imm = c("NI", "NI"),
#' epi = c("E", "E"),
#' n = c(1, 1)
#' )
#'
#'
#' startvec(ward_names, pop_size_P, pop_size_H, nVisits, LS, introduction)
#'
#' @export

startvec <- function(ward_names,
                     pop_size_P,
                     pop_size_H,
                     nVisits,
                     LS,
                     matContact = NULL,
                     IMMstate = NULL,
                     EPIstate = NULL,
                     SA = FALSE,
                     nH_SA = NULL,
                     verbose = TRUE) {
  # Checks.
  # vector format
  if (!is.vector(ward_names) |
      !is.vector(pop_size_P) |
      !is.vector(pop_size_H) | !is.vector(nVisits) | !is.vector(LS))
    stop("ward_names, pop_size_P, pop_size_H, nVisits and LS must be vectors.")

  # logical format
  if (!is.logical(SA))
    stop("SA must be logical")

  # vector lengths
  if (!identical(
    length(ward_names),
    length(pop_size_P),
    length(pop_size_H),
    length(LS),
    length(nVisits)
  )) {
    stop("ward_names, pop_size_P, pop_size_H, nVisits and LS vectors must be of equal length.")
  }

  # FIX ME: adapt to IMMstate and EPIstate

  if (!is.null(IMMstate)) {
    if (NA %in% match(IMMstate$pop, c("P", "H")))
      stop("IMMstate population column can only contains 'p' or 'h'")

    if (NA %in% match(IMMstate$imm  , c("NI", "LI", "HI")))
      stop("IMMstate immunity column can only contains 'NI', 'LI' or 'HI'")

    if (NA %in% match(IMMstate$ward, ward_names))
      stop("IMMstate ward column can only contains ward names present in the ward_names vector")
  }

  if (!is.null(EPIstate)) {
    if (NA %in% match(EPIstate$pop, c("P", "H")))
      stop("EPIstate population column can only contains 'p' or 'h'")

    if (NA %in% match(EPIstate$imm  , c("NI", "LI", "HI")))
      stop("EPIstate immunity column can only contains 'NI', 'LI' or 'HI'")

    if (NA %in% match(EPIstate$ward, ward_names))
      stop("EPIstate ward column can only contains ward names present in the ward_names vector")


    if (NA %in% match(EPIstate$epi  , c("S", "E", "EA", "ES", "IA", "IM", "IS")))
      stop(
        "In EPIstate, the currently implemented epidemiological states are: susceptible ('S'), Incubating not contagious ('E'), Incubating contagious to become asymptomatic ('EA'), Incubating contagious to become symptomatic ('ES'), Infectious asymptomatic ('IA'), Infectious symptomatic with mild symptoms ('IM'), Infectious symptomatic with severe symptoms ('IS')"
      )
  }

  # Check nH_SA if SA is TRUE
  if (isTRUE(SA)) {
    if (!length(nH_SA) %in% c(1, length(ward_names)))
      stop(
        "nH_SA must be either a unique value, commun to all wards, or one value per ward. The vector length must be 1 or identical to wards names vector length."
      )
    if (FALSE %in% (nH_SA > 0))
      stop("nH_SA must be positive value (>0).")
  }

  if (isTRUE(verbose))
    message("Warning: ward_names, pop_size_P, pop_size_H and LS vectors must be in the same order.")

  # SAp_S_NI
  compartments <-
    expand.grid(
      pop = c("PW", "H"),
      epistate = c("S", "E", "EA", "ES", "IA", "IM", "IS"),
      IMMstate = c("NI", "LI", "HI")
    )

  if (isTRUE(SA))
    compartments <-
    expand.grid(
      pop = c("PSA", "PW", "H"),
      epistate = c("S", "E", "EA", "ES", "IA", "IM", "IS"),
      IMMstate = c("NI", "LI", "HI")
    )

  setDT(compartments)

  compartments %<>% .[order(pop, epistate, IMMstate)]
  compartments %<>% .[, paste(pop, epistate, sep = "_") %>% paste(., IMMstate, sep =
                                                                    "_")]

  compartments <-
    rbind(compartments, paste0(compartments, "_T")) %>% c

  compartments %<>% c(
    .,
    c(
      "ISO",
      "IC",
      "SL",
      "ESL",
      "nTestP",
      "nTestH",
      "infP",
      "infH",
      "infHout",
      "incPA",
      "incPM",
      "incPS",
      "incHA",
      "incHM",
      "incHS",
      "nadm" ,
      "admInf"
    )
  )

  # build matrix
  xstart <- matrix(0,
                   ncol = length(compartments),
                   nrow = length(ward_names))

  # add row and column names
  rownames(xstart) <- ward_names
  colnames(xstart) <- compartments

  # Set population size
  xstart[, "PW_S_NI"] <- pop_size_P
  xstart[, "H_S_NI"] <- pop_size_H

  # update immunity levels based on IMMstate
  if (!is.null(IMMstate))
    for (row in IMMstate %>% nrow %>% seq) {
      row %<>% IMMstate[., ]

      if (row[["pop"]] == "P") {
        xstart[row[["ward"]], paste0(c("PW", "S", "NI"), collapse = "_")] %<>% subtract(as.numeric(row[["n"]]))
        xstart[row[["ward"]], paste0(c("PW", "S", row[["imm"]]), collapse = "_")] %<>% add(as.numeric(row[["n"]]))
      }
      if (row[["pop"]] == "H") {
        xstart[row[["ward"]], paste0(c("H", "S", "NI"), collapse = "_")] %<>% subtract(as.numeric(row[["n"]]))
        xstart[row[["ward"]], paste0(c("H", "S", row[["imm"]]), collapse = "_")] %<>% add(as.numeric(row[["n"]]))
      }

      if (TRUE %in% (xstart < 0))
        stop(
          paste(
            "In IMMState, the number of individuals with non null immunity level cannot be superior to the population size. See ward",
            row[["ward"]]
          )
        )

    }

  # update epidemiological levels based on EPIstate
  if (!is.null(EPIstate))
    for (row in EPIstate %>% nrow %>% seq) {
      row %<>% EPIstate[., ]


      if (row[["pop"]] == "P") {
        xstart[row[["ward"]], paste0(c("PW", "S", row[["imm"]]), collapse = "_")] %<>% subtract(as.numeric(row[["n"]]))
        xstart[row[["ward"]], paste0(c("PW", row[["epi"]], row[["imm"]]), collapse = "_")] %<>% add(as.numeric(row[["n"]]))
      }
      if (row[["pop"]] == "H") {
        xstart[row[["ward"]], paste0(c("H", "S", row[["imm"]]), collapse = "_")] %<>% subtract(as.numeric(row[["n"]]))
        xstart[row[["ward"]], paste0(c("H", row[["epi"]], row[["imm"]]), collapse = "_")] %<>% add(as.numeric(row[["n"]]))
      }

      if (TRUE %in% (xstart < 0))
        stop(
          paste(
            "In EPIstate, the number of non susceptible individuals cannot be superior to the population size of a specific compartment. See ward",
            row[["ward"]]
          )
        )

    }

  u0 <- xstart

  # set local data/parameters
  ldata <- matrix(
    data = 0,
    nrow = 4L,
    ncol = nrow(xstart),
    dimnames = list(c("nP", "tLS", "nV", "nH_SA"),
                    NULL)
  )

  if (isTRUE(SA)) {
    if (is.null(nH_SA))
      ldata["nH_SA", ] <- pop_size_H
    else
      ldata["nH_SA", ] <- nH_SA

  } else
    ldata %<>% .[rownames(.) != "nH_SA", ]

  ldata["nP", ] <- pop_size_P
  # Number of visit per patient per day
  ldata["nV", ] <- nVisits / pop_size_P
  # Dayly turnover ## FIX ME >> discuss to be sure
  ldata["tLS", ] <- LS

  if (is.null(matContact)) {
    matContact <- rbind(diag(1, nrow(u0)), diag(1, nrow(u0)))
  } else {
    HinW <- t(matContact)
    PwithHfromW <- apply(matContact, 2, function(x)
      x / sum(x))
    matContact <- rbind(HinW, PwithHfromW)
  }

  rownames(matContact) <-
    c(paste0("H_dest_", ward_names),
      paste0("H_orig_", ward_names))

  ldata %<>% rbind(matContact, .)

  colnames(ldata) <- ward_names

  return(list(u0 = u0,
              ldata = ldata))

}
