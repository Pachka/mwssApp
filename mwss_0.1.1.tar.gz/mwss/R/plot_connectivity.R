#' Plot the wards network based on shared health care workers
#'
#' @description \code{plot_connectivity} returns an igraph object ready to be plot with individual editing (refer to igraph package or https://igraph.org/r/doc/plot.common.html). The function also returns a generic png plot. Wards are reprensented according to the patient population size. Connexion between size depends on values in the contact matrix.
#'
#' @usage plot_connectivity(matContact, size)
#'
#' @param matContact Matrix reporting  the proportion of time spent by health care workers in the different wards.
#' @param size Vector of population size in each ward (beds, HCWS or sum of both).
#' @param vertexcexrate Integer, proportional coefficient to adjust vertex names size.
#' @param edgewidthrate Integer, proportional coefficient to adjust edge width.
#' @param netobj Logical, define if the function return a network oject (TRUE) or a plot (FALSE). Default is FALSE.
#' @param verbose Logical, activate production of details messages.
#'
#' @import igraph
#' @importFrom graphics plot
#' @importFrom network plot.network
#'
#' @return Plot of connexions between wards.
#' @examples
#'
#' @export

plot_connectivity <- function(matContact, size, vertexcexrate = 3, edgewidthrate = 5, netobj = FALSE, verbose = TRUE){

  if(is.null(names(size))){
  names(size) <- colnames(matContact)
  if(verbose){
  message("Names were attributed to the size values based on the contact matrix order.")
  print(size)
  }
  }

  if(!identical(colnames(matContact), rownames(matContact)) |
     !identical(colnames(matContact), names(size)))
    stop("The contact matrix should have the same names in rows and columns. Those names have to be the same than in the size vector.")

# initialize link list
connexions <- data.frame(ward1=character(),
                         ward2=character(),
                         nHCWS=numeric(),
                 stringsAsFactors=FALSE)


connexions <- lapply(seq(nrow(matContact)), function(ward){

  from_ward <- matContact %>% rownames %>% .[ward]
  to_ward <- matContact[ward, ] %>% names %>% .[. != from_ward]
  nHCWS <- matContact[from_ward,to_ward] %>% unlist

  data.frame(from_ward, to_ward, nHCWS)
}) %>% do.call(rbind, .)


g <- wardsNet(connexions, size, edgewidthrate)

if(isTRUE(netobj))
  return(g)

# If the nodes are connected
if(sum(connexions$nHCWS!=0) > 0){

  vnames <- network::get.vertex.attribute(g, "vertex.names")

  plot.network(
    g,
    # our network object
    vertex.col = "grey",
    # color nodes by gender
    vertex.cex = (size[vnames]/max(size[vnames]))*vertexcexrate,
    edge.lwd = network::get.edge.attribute(g, "weight"),
    # size nodes by their age
    displaylabels = T,
    # show the node names
    label.pos = 0 # display the names directly over nodes
  )

} else {

  plot.network(
    g,
    # our network object
    vertex.col = "grey",
    # color nodes by gender
    vertex.cex = (size / max(size)) * vertexcexrate,
    # size nodes by their age
    displaylabels = T,
    # show the node names
    label.pos = 0 # display the names directly over nodes
  )

}
}


wardsNet <- function(connexions, size, edgewidthrate){

  if(sum(connexions$nHCWS!=0) > 0){

    connexions %<>% .[.$nHCWS!=0, ]

    g <- graph_from_data_frame(connexions, directed = TRUE, vertices = data.frame(name = names(size), size = size))

    E(g)$weight <- connexions$nHCWS %<>% divide_by(max(.)) %>% multiply_by(edgewidthrate)

    g %<>% intergraph::asNetwork(.)

  } else {
    num_nodes <- length(size)
    my_sociomatrix <- matrix(rep(0, num_nodes * num_nodes),
                             # edge values
                             nrow = num_nodes,
                             #nrow must be same as ncol
                             ncol = num_nodes)

    diag(my_sociomatrix) <- 0

    g <- as.network(
      x = my_sociomatrix,
      # the network object
      directed = TRUE,
      # specify whether the network is directed
      loops = FALSE,
      # do we allow self ties (should not allow them)
      matrix.type = "adjacency" # the type of input
    )

  }

  return(g)
}

