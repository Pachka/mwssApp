#' Plot ...
#'
#' @description \code{plot_test} returns an plot where ...
#'
#' @usage plot_test(trajmwss)
#'
#' @param trajmwss FIX ME
#' @param daysint FIX ME
#' @param iter FIX ME
#' @param ward FIX ME
#'
#' @return Plot of
#'
#' @export

plot_test <- function(trajmwss,
                      daysint = 1,
                      iter = FALSE,
                      ward = FALSE,
                      pop = NULL,
                      scale = 0) {

  if (!isFALSE(ward) & scale == 0) {
    scale = 1
  }

  ntest <- summary(trajmwss,
                   scale = scale,
                   focus = "test")$ndtest

  if (scale == 1 & ward %in% trajmwss[[1]]$node)
    ntest %<>% .[node == ward]

  if (is.numeric(iter))
    ntest %<>% .[iteration == iter]

  if (is.null(pop))
    ntest[, ndtest := n_dtestP + n_dtestH]
  else
    if (pop == "P")
      setnames(ntest, "n_dtestP", "ndtest")
  else
    if (pop == "H")
      setnames(ntest, "n_dtestH", "ndtest")


  if (scale == 1)
    ntest %<>% .[, c("iteration", "node", "time", "ndtest")]
  else
    ntest %<>% .[, c("iteration", "time", "ndtest")]

  ntest[, dint := cut(
    time,
    c(seq(
      min(ntest$time),
      max(ntest$time),
      daysint
    ), max(ntest$time)) %>% unique,
    include.lowest = T,
    right = F,
    ordered_result = T
  )]

  levels(ntest$dint) <- ntest$dint %>% nlevels %>% seq

  if (length(unique(ntest$dint)) >= 30)
    if (scale == 1)
      ntest[, avntest := mean(ndtest), by = c("dint", "node")]
  else
    ntest[, avntest := mean(ndtest), by = c("dint")]

  if (is.null(pop))
    ylabpop <- "both patients and professionals"
  else
    if (pop == "P")
      ylabpop <- "patients"
  else
    if (pop == "H")
      ylabpop <- "professionals"

  if (daysint > 1)
    ylabel <-
    paste0("Daily number of tests of ",
           ylabpop,
           " over ",
           daysint,
           "-days periods")
  else
    ylabel <- paste0("Daily number of tests of ", ylabpop)

  if (scale == 1) {
    if (daysint > 1 & length(unique(ntest$dint)) < 30)
      p <-
        ggplot(ntest, aes(
          x = dint,
          y = ndtest,
          fill = node %>% as.factor
        )) +
        geom_boxplot(
          outlier.colour = "red",
          outlier.shape = 8,
          outlier.size = 2,
          notch = FALSE
        ) +
        facet_grid(node %>% as.factor ~ .) +
        xlab(paste0("Time steps (", daysint, " days)")) +
        ylab(ylabel) +
        theme(legend.position = "none")

    if (daysint > 1 & length(unique(ntest$dint)) >= 30) {
      p <-
        ggplot(
          ntest,
          aes(
            x = dint  %>% as.numeric,
            y = avntest,
            group = node %>% as.factor,
            colour = node %>% as.factor
          )
        ) +
        geom_line() + geom_point() +
        facet_grid(node %>% as.factor ~ .) +
        xlab(paste0("Time steps (", daysint, " days)")) +
        ylab(ylabel) +
        theme(legend.position = "none")
    }

    #### do not aggregate periods

    if (daysint == 1 & length(unique(ntest$dint)) < 30)
      p <-
        ggplot(ntest, aes(
          x = dint,
          y = ndtest,
          fill = node %>% as.factor
        )) +
        geom_boxplot(
          outlier.colour = "red",
          outlier.shape = 8,
          outlier.size = 2,
          notch = FALSE
        ) +
        facet_grid(node %>% as.factor ~ .) +
        xlab("Time (day)") +
        ylab(ylabel) +
        theme(legend.position = "none")

    #### use geomline when exceeding 30 time steps

    if (daysint == 1 & length(unique(ntest$dint)) >= 30) {
      p <-
        ggplot(
          ntest,
          aes(
            x = dint %>% as.numeric,
            y = avntest,
            group = node %>% as.factor,
            colour = node %>% as.factor
          )
        ) +
        geom_line() + geom_point() +
        facet_grid(node %>% as.factor ~ .) +
        xlab("Time (day)") +
        ylab(ylabel) +
        theme(legend.position = "none")
    }

  } else {
    if (daysint > 1 & length(unique(ntest$dint)) < 30)
      p <-  ggplot(ntest, aes(x = dint, y = ndtest)) +
        geom_boxplot(
          outlier.colour = "red",
          outlier.shape = 8,
          outlier.size = 2,
          notch = FALSE
        ) +
        xlab(paste0("Time steps (", daysint, " days)")) +
        ylab(ylabel) +
        theme(legend.position = "none")

    if (daysint > 1 & length(unique(ntest$dint)) >= 30) {
      p <-  ggplot(ntest, aes(x = dint %>% as.numeric, y = avntest)) +
        geom_line() + geom_point() +
        xlab(paste0("Time steps (", daysint, " days)")) +
        ylab(ylabel) +
        theme(legend.position = "none")
    }

    #### do not aggregate periods

    if (daysint == 1 & length(unique(ntest$dint)) < 30)
      p <-  ggplot(ntest, aes(x = dint, y = ndtest)) +
        geom_boxplot(
          outlier.colour = "red",
          outlier.shape = 8,
          outlier.size = 2,
          notch = FALSE
        ) +
        xlab("Time (day)") +
        ylab(ylabel) +
        theme(legend.position = "none")

    #### use geomline when exceeding 30 time steps

    if (daysint == 1 & length(unique(ntest$dint)) >= 30) {
      p <-  ggplot(ntest, aes(x = dint %>% as.numeric, y = avntest)) +
        geom_line() + geom_point() +
        xlab("Time (day)") +
        ylab(ylabel) +
        theme(legend.position = "none")
    }
  }


  return(p)

}
