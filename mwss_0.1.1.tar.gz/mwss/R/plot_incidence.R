#' Plot ...
#'
#' @description \code{plot_incidence} returns an plot where ...
#'
#' @usage plot_incidence(trajinc)
#'
#' @param trajinc FIX ME
#' @param scale FIX ME
#' @param pop FIX ME
#' @param iter FIX ME
#' @param ward FIX ME
#' @param display_sd FIX ME
#'
#' @return Plot of
#'
#' @export

plot_incidence <- function(trajinc,
                           scale = 1,
                           pop = FALSE,
                           iter = FALSE,
                           ward = FALSE,
                           display_sd = T) {

  if(scale == 0 & !isFALSE(ward))
    stop("At the facility scale ('0') no ward can be specified")

  if(is.numeric(iter))
    trajinc %<>% .[iter]

  if(scale == 1){
  if(ward %in% trajinc[[1]]$node)
    trajinc %<>% lapply(., function(sim)
      sim %<>% .[node == ward])

    trajinc <- lapply(seq(length(trajinc)), function(sim) {
      trajinc[[sim]][, iteration := sim]
      trajinc[[sim]]
    }
    ) %>% do.call(rbind, .)

    trajinc[, ':='(
      incP = sum(incPA + incPM + incPS),
      incPsymp = sum(incPM + incPS),
      incH = sum(incHA + incHM + incHS),
      incHsymp = sum(incHM + incHS),
      inc = sum(incPA + incPM + incPS + incHA + incHM + incHS)
    ), by = c("iteration", "time", "node")]

    trajinc[, ':='(
      mean_incP = mean(incP),
      sd_incP = sd(incP),
      mean_incPsymp = mean(incPsymp),
      sd_incPsymp = sd(incPsymp),
      mean_incH = mean(incH),
      sd_incH = sd(incH),
      mean_incHsymp = mean(incHsymp),
      sd_incHsymp = sd(incHsymp),
      mean_inc = mean(inc),
      sd_inc = sd(inc)
    ), by=c("time", "node")]

    if(pop == "P") {
      setnames(trajinc, "mean_incP", "meanVal")
      setnames(trajinc, "sd_incP", "sdVal")
      ylabel = "Cummulative incidence among patients"
    } else
      if(pop == "Psymp") {
        setnames(trajinc, "mean_incPsymp", "meanVal")
        setnames(trajinc, "sd_incPsymp", "sdVal")
        ylabel = "Cummulative incidence among patients (only considering symptomatics)"
      } else
        if(pop == "H") {
          setnames(trajinc, "mean_incH", "meanVal")
          setnames(trajinc, "sd_incH", "sdVal")
          ylabel = "Cummulative incidence among professionals"
        } else
          if(pop == "Hsymp") {
            setnames(trajinc, "mean_incHsymp", "meanVal")
            setnames(trajinc, "sd_incHsymp", "sdVal")
            ylabel = "Cummulative incidence among professionals (only considering symptomatics)"
          } else
            if(isFALSE(pop)) {
              setnames(trajinc, "mean_inc", "meanVal")
              setnames(trajinc, "sd_inc", "sdVal")
              ylabel = "Cummulative incidence (patients + professionals)"
            }

    data <- trajinc[, c("time", "node", "meanVal", "sdVal")] %>% unique

  p <- ggplot(data = data, aes(x = time,
                                y = meanVal,
                                group = node %>% as.factor, fill = node %>% as.factor)) +
    geom_bar(stat="identity",
             color = "grey",
             width = 1) +
    facet_grid(node %>% as.factor ~ .) +
    xlab("Time (day)") +
    ylab(ylabel) +
    theme(legend.position = "none")

  if(isTRUE(display_sd) & is.logical(iter))
    p <- p +  geom_errorbar(aes(ymin = ifelse(meanVal - sdVal >= 0, meanVal - sdVal, 0),
                                ymax = meanVal + sdVal),
                            colour = "grey", alpha = 0.75,
                            width=.2,
                            position=position_dodge(.9))
  }

  if(scale == 0){

    trajinc <- lapply(seq(length(trajinc)), function(sim) {
      trajinc[[sim]][, iteration := sim]
      trajinc[[sim]]
    }
    )

    trajinc %<>% do.call(rbind, .)

    trajinc[, ':='(
        incP = sum(incPA + incPM + incPS),
        incPsymp = sum(incPM + incPS),
        incH = sum(incHA + incHM + incHS),
        incHsymp = sum(incHM + incHS),
        inc = sum(incPA + incPM + incPS + incHA + incHM + incHS)
      ), by = c("iteration", "time")]

    trajinc[, ':='(
      mean_incP = mean(incP),
      sd_incP = sd(incP),
      mean_incPsymp = mean(incPsymp),
      sd_incPsymp = sd(incPsymp),
      mean_incH = mean(incH),
      sd_incH = sd(incH),
      mean_incHsymp = mean(incHsymp),
      sd_incHsymp = sd(incHsymp),
      mean_inc = mean(inc),
      sd_inc = sd(inc)
    ), by=c("time")]

    if(pop == "P") {
      setnames(trajinc, "mean_incP", "meanVal")
      setnames(trajinc, "sd_incP", "sdVal")
      ylabel = "Cummulative incidence among patients"
    } else
      if(pop == "Psymp") {
        setnames(trajinc, "mean_incPsymp", "meanVal")
        setnames(trajinc, "sd_incPsymp", "sdVal")
        ylabel = "Cummulative incidence among patients (only considering symptomatics)"
      } else
        if(pop == "H") {
          setnames(trajinc, "mean_incH", "meanVal")
          setnames(trajinc, "sd_incH", "sdVal")
          ylabel = "Cummulative incidence among professionals"
        } else
          if(pop == "Hsymp") {
            setnames(trajinc, "mean_incHsymp", "meanVal")
            setnames(trajinc, "sd_incHsymp", "sdVal")
            ylabel = "Cummulative incidence among professionals (only considering symptomatics)"
          } else
            if(isFALSE(pop)) {
              setnames(trajinc, "mean_inc", "meanVal")
              setnames(trajinc, "sd_inc", "sdVal")
              ylabel = "Cummulative incidence (patients + professionals)"
            }

      data <- trajinc[, c("time", "meanVal", "sdVal")] %>% unique

    p <- ggplot(data, aes(x=time, y=meanVal)) +
      geom_bar(stat= "identity", color = "grey", width = 1) +
      xlab("Time (day)") +
      ylab(ylabel) +
      theme(legend.position = "none")

    if(isTRUE(display_sd) & is.logical(iter))
      p <- p +  geom_errorbar(aes(ymin = ifelse(meanVal - sdVal >= 0, meanVal - sdVal, 0),
                                  ymax = meanVal + sdVal),
                              colour = "grey", alpha = 0.75,
                              width=.2,
                              position=position_dodge(.9))
  }

  return(p)
}
