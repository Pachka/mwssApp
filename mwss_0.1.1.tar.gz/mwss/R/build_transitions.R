#' Generate transitions
#'
#' @description
#'
#' @usage build_transitions()
#'
#' @return String containing transitions used by SimInf package
#'

build_transitions <- function(SA){

  if(class(SA) != "logical") stop("SA must be logical - see build transition function")

  ### Write transitions

  nPSA <-
    "(PSA_S_NI + PSA_S_NI_T + PSA_S_LI + PSA_S_LI_T + PSA_S_HI + PSA_S_HI_T + PSA_E_NI + PSA_E_NI_T + PSA_E_LI + PSA_E_LI_T + PSA_E_HI + PSA_E_HI_T + PSA_EA_NI + PSA_EA_NI_T + PSA_EA_LI + PSA_EA_LI_T + PSA_EA_HI + PSA_EA_HI_T + PSA_ES_NI + PSA_ES_NI_T + PSA_ES_LI + PSA_ES_LI_T + PSA_ES_HI + PSA_ES_HI_T + PSA_IA_NI + PSA_IA_NI_T + PSA_IA_LI + PSA_IA_LI_T + PSA_IA_HI + PSA_IA_HI_T + PSA_IM_NI + PSA_IM_NI_T + PSA_IM_LI + PSA_IM_LI_T + PSA_IM_HI + PSA_IM_HI_T + PSA_IS_NI + PSA_IS_NI_T + PSA_IS_LI + PSA_IS_LI_T + PSA_IS_HI + PSA_IS_HI_T)"
  infPSA <-
    "(PSA_EA_NI + PSA_EA_NI_T + PSA_EA_LI + PSA_EA_LI_T + PSA_EA_HI + PSA_EA_HI_T + PSA_ES_NI + PSA_ES_NI_T + PSA_ES_LI + PSA_ES_LI_T + PSA_ES_HI + PSA_ES_HI_T + PSA_IA_NI + PSA_IA_NI_T + PSA_IA_LI + PSA_IA_LI_T + PSA_IA_HI + PSA_IA_HI_T + PSA_IM_NI + PSA_IM_NI_T + PSA_IM_LI + PSA_IM_LI_T + PSA_IM_HI + PSA_IM_HI_T + PSA_IS_NI + PSA_IS_NI_T + PSA_IS_LI + PSA_IS_LI_T + PSA_IS_HI + PSA_IS_HI_T)"
  nPW <-
    "(PW_S_NI + PW_S_NI_T + PW_S_LI + PW_S_LI_T + PW_S_HI + PW_S_HI_T + PW_E_NI + PW_E_NI_T + PW_E_LI + PW_E_LI_T + PW_E_HI + PW_E_HI_T + PW_EA_NI + PW_EA_NI_T + PW_EA_LI + PW_EA_LI_T + PW_EA_HI + PW_EA_HI_T + PW_ES_NI + PW_ES_NI_T + PW_ES_LI + PW_ES_LI_T + PW_ES_HI + PW_ES_HI_T + PW_IA_NI + PW_IA_NI_T + PW_IA_LI + PW_IA_LI_T + PW_IA_HI + PW_IA_HI_T + PW_IM_NI + PW_IM_NI_T + PW_IM_LI + PW_IM_LI_T + PW_IM_HI + PW_IM_HI_T + PW_IS_NI + PW_IS_NI_T + PW_IS_LI + PW_IS_LI_T + PW_IS_HI + PW_IS_HI_T)"
  infPW <-
    "(PW_EA_NI + PW_EA_NI_T + PW_EA_LI + PW_EA_LI_T + PW_EA_HI + PW_EA_HI_T + PW_ES_NI + PW_ES_NI_T + PW_ES_LI + PW_ES_LI_T + PW_ES_HI + PW_ES_HI_T + PW_IA_NI + PW_IA_NI_T + PW_IA_LI + PW_IA_LI_T + PW_IA_HI + PW_IA_HI_T + PW_IM_NI + PW_IM_NI_T + PW_IM_LI + PW_IM_LI_T + PW_IM_HI + PW_IM_HI_T + PW_IS_NI + PW_IS_NI_T + PW_IS_LI + PW_IS_LI_T + PW_IS_HI + PW_IS_HI_T)"
  nH <-
    "(H_S_NI + H_S_NI_T + H_S_LI + H_S_LI_T + H_S_HI + H_S_HI_T + H_E_NI + H_E_NI_T + H_E_LI + H_E_LI_T + H_E_HI + H_E_HI_T + H_EA_NI + H_EA_NI_T + H_EA_LI + H_EA_LI_T + H_EA_HI + H_EA_HI_T + H_ES_NI + H_ES_NI_T + H_ES_LI + H_ES_LI_T + H_ES_HI + H_ES_HI_T + H_IA_NI + H_IA_NI_T + H_IA_LI + H_IA_LI_T + H_IA_HI + H_IA_HI_T + H_IM_NI + H_IM_NI_T + H_IM_LI + H_IM_LI_T + H_IM_HI + H_IM_HI_T + H_IS_NI + H_IS_NI_T + H_IS_LI + H_IS_LI_T + H_IS_HI + H_IS_HI_T)"
  infH <-
    "(H_EA_NI + H_EA_NI_T + H_EA_LI + H_EA_LI_T + H_EA_HI + H_EA_HI_T + H_ES_NI + H_ES_NI_T + H_ES_LI + H_ES_LI_T + H_ES_HI + H_ES_HI_T + H_IA_NI + H_IA_NI_T + H_IA_LI + H_IA_LI_T + H_IA_HI + H_IA_HI_T + H_IM_NI + H_IM_NI_T + H_IM_LI + H_IM_LI_T + H_IM_HI + H_IM_HI_T + H_IS_NI + H_IS_NI_T + H_IS_LI + H_IS_LI_T + H_IS_HI + H_IS_HI_T)"

  # Forceq of infection
  # "wpropInfHorig", "wpropInfHdest", "wpropInfPSAdest", "wpropInfPWdest"

  lambdaPSA <-
    paste("pconta * ((1 - epsPPSA) * ctcPPSA * (", infPSA, "/", nPSA,
          ") + (1 - epsHPSA) * ctcHPSA * wpropInfHorig)")

  lambdaPW <-
    paste("pconta * ((1 - epsPPW) * ctcPPW * (", infPW, "/", nPW,
          ") + (1 - epsHPW) * ctcHPW * wpropInfHorig + (1 - epsVPW) * ctcV * nV * (prev * (1-rE)))")

  tHP <- paste("ctcHPSA *",nPSA," + ctcHPW *",nPW)
  tHP_H <- paste("(",tHP,")/", nH)
  tHPsa_Hsa <- paste("(ctcHPSA *",nPSA,")/nH_SA")
  tHPw_Hsa <- paste(tHP_H," - ",tHPsa_Hsa)

  lambdaHw <-
    paste("pconta * ((1 - epsPHW) * ",tHP_H ," * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest)")

  lambdaHsa <-
    paste(
      # For HW in charge of admissions: infection per patients during admission and in the wards
      "pconta * ((nH_SA /", nH,") * ( (1 - epsPHSA) * ", tHPsa_Hsa ," * wpropInfPSAdest + (1 - epsPHW) * ", tHPw_Hsa ," * wpropInfPWdest) + ",
      # For HW not in charge of admissions: infection per patients and HW in the wards
      "((",nH," - nH_SA) /", nH,") * ((1 - epsHHW) * ctcHH * wpropInfHdest))") %>% gsub("[\r\n]", "", .)

  lambdaHsaw <-
    paste(
      # For HW in charge of admissions: infection per patients during admission and in the wards
      "pconta * ((nH_SA /", nH,") * ( (1 - epsPHSA) * ", tHPsa_Hsa ," * wpropInfPSAdest + (1 - epsPHW) * ", tHPw_Hsa ," * wpropInfPWdest) + ",
      # For HW not in charge of admissions: infection per patients and HW in the wards
      "((",nH," - nH_SA) /", nH,") * ( (1 - epsPHW) * ",tHP_H ," * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest))") %>% gsub("[\r\n]", "", .)

  # Is there any available bed?
  if(SA)
  SPACE <- paste0("nP - (", nPSA," + ", nPW," + ISO + IC) > 0") else
    SPACE <- paste0("nP - (", nPW," + ISO + IC) > 0")

  # Is there any patient to admit?
  PSAEMPTY <- paste0(nPSA," < 1")
  PWEMPTY <- paste0(nPW," < 1")
  HEMPTY <- paste0(nH," < 1")
  PEMPTY <- paste0("(", nPSA," + ", nPW, ") < 1")


  transitions <-
    ## Patients
    c(####
      #### Ward
      ####
      ### Test
      ## No Immunity
      # untested to tested
      "PW_S_NI -> PW_S_NI * ptestPWNI * ( 1 / tbtwtestP) -> PW_S_NI_T",
      "PW_E_NI -> PW_E_NI * ptestPWNI * ( 1 / tbtwtestP) -> PW_E_NI_T",
      "PW_EA_NI -> PW_EA_NI * ptestPWNI * ( 1 / tbtwtestP) -> PW_EA_NI_T",
      "PW_ES_NI -> PW_ES_NI * ptestPWNI * ( 1 / tbtwtestP) -> PW_ES_NI_T",
      "PW_IA_NI -> PW_IA_NI * ptestPWNI * ( 1 / tbtwtestP) -> PW_IA_NI_T",
      "PW_IM_NI -> PW_IM_NI * ptestPWsymp * ( 1 / tbeftestPsymp) -> PW_IM_NI_T",
      "PW_IS_NI -> PW_IS_NI * ptestPWsymp * ( 1 / tbeftestPsymp) -> PW_IS_NI_T",
      # tested to untested (negative test result)
      "PW_S_NI_T -> PW_S_NI_T * (speW + (1 - speW) * (1 - pISO)) * ( 1 / ttestPW) -> PW_S_NI + nTestP",
      "PW_E_NI_T -> PW_E_NI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_E_NI + nTestP",
      "PW_EA_NI_T -> PW_EA_NI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_EA_NI + nTestP",
      "PW_ES_NI_T -> PW_ES_NI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_ES_NI + nTestP",
      "PW_IA_NI_T -> PW_IA_NI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_IA_NI + nTestP",
      "PW_IM_NI_T -> PW_IM_NI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IM_NI + nTestP",
      "PW_IS_NI_T -> PW_IS_NI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IS_NI + nTestP",
      # tested to confinement (positive test result)
      "PW_S_NI_T -> PW_S_NI_T * (1 - speW) * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_E_NI_T -> PW_E_NI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_EA_NI_T -> PW_EA_NI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_ES_NI_T -> PW_ES_NI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_IA_NI_T -> PW_IA_NI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_IM_NI_T -> PW_IM_NI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
      "PW_IS_NI_T -> PW_IS_NI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
      ## Low immunity
      # untested to tested
      "PW_S_LI -> PW_S_LI * ptestPWLI * ( 1 / tbtwtestP) -> PW_S_LI_T",
      "PW_E_LI -> PW_E_LI * ptestPWLI * ( 1 / tbtwtestP) -> PW_E_LI_T",
      "PW_EA_LI -> PW_EA_LI * ptestPWLI * ( 1 / tbtwtestP) -> PW_EA_LI_T",
      "PW_ES_LI -> PW_ES_LI * ptestPWLI * ( 1 / tbtwtestP) -> PW_ES_LI_T",
      "PW_IA_LI -> PW_IA_LI * ptestPWLI * ( 1 / tbtwtestP) -> PW_IA_LI_T",
      "PW_IM_LI -> PW_IM_LI * ptestPWsymp * ( 1 / tbeftestPsymp) -> PW_IM_LI_T",
      "PW_IS_LI -> PW_IS_LI * ptestPWsymp * ( 1 / tbeftestPsymp) -> PW_IS_LI_T",
      # tested to untested (negative test result or confirmed but no confinement protocol)
      "PW_S_LI_T -> PW_S_LI_T * (speW + (1-speW) * (1 - pISO)) * ( 1 / ttestPW) -> PW_S_LI + nTestP",
      "PW_E_LI_T -> PW_E_LI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_E_LI + nTestP",
      "PW_EA_LI_T -> PW_EA_LI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_EA_LI + nTestP",
      "PW_ES_LI_T -> PW_ES_LI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_ES_LI + nTestP",
      "PW_IA_LI_T -> PW_IA_LI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_IA_LI + nTestP",
      "PW_IM_LI_T -> PW_IM_LI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IM_LI + nTestP",
      "PW_IS_LI_T -> PW_IS_LI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IS_LI + nTestP",
      # tested to confinement (positive test result)
      "PW_S_LI_T -> PW_S_LI_T * (1 - speW) * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_E_LI_T -> PW_E_LI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_EA_LI_T -> PW_EA_LI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_ES_LI_T -> PW_ES_LI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_IA_LI_T -> PW_IA_LI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_IM_LI_T -> PW_IM_LI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
      "PW_IS_LI_T -> PW_IS_LI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
      ## High immunity
      # untested to tested
      "PW_S_HI -> PW_S_HI * ptestPWHI * ( 1 / tbtwtestP) -> PW_S_HI_T",
      "PW_E_HI -> PW_E_HI * ptestPWHI * ( 1 / tbtwtestP) -> PW_E_HI_T",
      "PW_EA_HI -> PW_EA_HI * ptestPWHI * ( 1 / tbtwtestP) -> PW_EA_HI_T",
      "PW_ES_HI -> PW_ES_HI * ptestPWHI * ( 1 / tbtwtestP) -> PW_ES_HI_T",
      "PW_IA_HI -> PW_IA_HI * ptestPWHI * ( 1 / tbtwtestP) -> PW_IA_HI_T",
      "PW_IM_HI -> PW_IM_HI * ptestPWsymp * ( 1 / tbeftestPsymp) -> PW_IM_HI_T",
      "PW_IS_HI -> PW_IS_HI * ptestPWsymp * ( 1 / tbeftestPsymp) -> PW_IS_HI_T",
      # tested to untested (negative test result or positive test result without confinement)
      "PW_S_HI_T -> PW_S_HI_T * (speW + (1-speW) * (1 - pISO)) * ( 1 / ttestPW) -> PW_S_HI + nTestP",
      "PW_E_HI_T -> PW_E_HI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_E_HI + nTestP",
      "PW_EA_HI_T -> PW_EA_HI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_EA_HI + nTestP",
      "PW_ES_HI_T -> PW_ES_HI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_ES_HI + nTestP",
      "PW_IA_HI_T -> PW_IA_HI_T * ((1 - senW) + senW * (1 - pISO)) * ( 1 / ttestPW) -> PW_IA_HI + nTestP",
      "PW_IM_HI_T -> PW_IM_HI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IM_HI + nTestP",
      "PW_IS_HI_T -> PW_IS_HI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IS_HI + nTestP",
      # tested to confinement (positive test result)
      "PW_S_HI_T -> PW_S_HI_T * (1 - speW) * ( 1 / ttestPW)* pISO-> ISO + nTestP",
      "PW_E_HI_T -> PW_E_HI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_EA_HI_T -> PW_EA_HI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_ES_HI_T -> PW_ES_HI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_IA_HI_T -> PW_IA_HI_T * senW * ( 1 / ttestPW) * pISO -> ISO + nTestP",
      "PW_IM_HI_T -> PW_IM_HI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
      "PW_IS_HI_T -> PW_IS_HI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
      ### Infection
      # pinfWp
      paste("PW_S_NI -> ", PWEMPTY,"? 0 : PW_S_NI * ", lambdaPW ," -> PW_E_NI + infP"),
      paste("PW_S_NI_T -> ", PWEMPTY,"? 0 : PW_S_NI_T * ", lambdaPW ," -> PW_E_NI_T + infP"),
      paste("PW_S_LI -> ", PWEMPTY,"? 0 : PW_S_LI * ", lambdaPW ," * rinfLI -> PW_E_LI + infP"),
      paste("PW_S_LI_T -> ", PWEMPTY,"? 0 : PW_S_LI_T * ", lambdaPW ," * rinfLI -> PW_E_LI_T + infP"),
      paste("PW_S_HI -> ", PWEMPTY,"? 0 : PW_S_HI * ", lambdaPW ," * rinfHI -> PW_E_HI + infP"),
      paste("PW_S_HI_T -> ", PWEMPTY,"? 0 : PW_S_HI_T * ", lambdaPW ," * rinfHI -> PW_E_HI_T + infP"),
      ### Disease cycle
      # NI
      "PW_E_NI -> PW_E_NI * ( 1 / tE) * (1 - psympNI) -> PW_EA_NI",
      "PW_EA_NI -> PW_EA_NI * ( 1 / tEA) -> PW_IA_NI + incPA",
      "PW_IA_NI -> PW_IA_NI * ( 1 / tIA) -> PW_S_HI",
      "PW_E_NI -> PW_E_NI * ( 1 / tE) * psympNI -> PW_ES_NI",
      "PW_ES_NI -> PW_ES_NI * ( 1 / tES) * (1 - psevNI * rsev) -> PW_IM_NI + incPM",
      "PW_ES_NI -> PW_ES_NI * ( 1 / tES) * psevNI * rsev -> PW_IS_NI + incPS",
      "PW_IM_NI -> PW_IM_NI * ( 1 / tIM) -> PW_S_HI",
      "PW_IS_NI -> PW_IS_NI * (1 - pIC) * ( 1 / tIS) -> PW_S_HI",
      "PW_IS_NI -> PW_IS_NI * pIC * ( 1 / tIS) -> IC",
      "PW_E_NI_T -> PW_E_NI_T * ( 1 / tE) * (1 - psympNI) -> PW_EA_NI_T",
      "PW_EA_NI_T -> PW_EA_NI_T * ( 1 / tEA) -> PW_IA_NI_T + incPA",
      "PW_IA_NI_T -> PW_IA_NI_T * ( 1 / tIA) -> PW_S_HI",
      "PW_E_NI_T -> PW_E_NI_T * ( 1 / tE) * psympNI -> PW_ES_NI_T",
      "PW_ES_NI_T -> PW_ES_NI_T * ( 1 / tES) * (1 - psevNI * rsev) -> PW_IM_NI_T + incPM",
      "PW_ES_NI_T -> PW_ES_NI_T * ( 1 / tES) * psevNI * rsev -> PW_IS_NI_T + incPS",
      "PW_IM_NI_T -> PW_IM_NI_T * ( 1 / tIM) -> PW_S_HI",
      "PW_IS_NI_T -> PW_IS_NI_T * (1 - pIC) * ( 1 / tIS) -> PW_S_HI",
      "PW_IS_NI_T -> PW_IS_NI_T * pIC * ( 1 / tIS) -> IC",
      # LI
      "PW_E_LI -> PW_E_LI * ( 1 / tE) * (1 - psympLI) -> PW_EA_LI",
      "PW_EA_LI -> PW_EA_LI * ( 1 / tEA) -> PW_IA_LI + incPA",
      "PW_IA_LI -> PW_IA_LI * ( 1 / tIA) -> PW_S_HI",
      "PW_E_LI -> PW_E_LI * ( 1 / tE) * psympLI -> PW_ES_LI",
      "PW_ES_LI -> PW_ES_LI * ( 1 / tES) * (1 - psevLI * rsev) -> PW_IM_LI + incPM",
      "PW_ES_LI -> PW_ES_LI * ( 1 / tES) * psevLI * rsev -> PW_IS_LI + incPS",
      "PW_IM_LI -> PW_IM_LI * ( 1 / tIM) -> PW_S_HI",
      "PW_IS_LI -> PW_IS_LI * (1 - pIC) * ( 1 / tIS) -> PW_S_HI",
      "PW_IS_LI -> PW_IS_LI * pIC * ( 1 / tIS) -> IC",
      "PW_E_LI_T -> PW_E_LI_T * ( 1 / tE) * (1 - psympLI) -> PW_EA_LI_T",
      "PW_EA_LI_T -> PW_EA_LI_T * ( 1 / tEA) -> PW_IA_LI_T + incPA",
      "PW_IA_LI_T -> PW_IA_LI_T * ( 1 / tIA) -> PW_S_HI",
      "PW_E_LI_T -> PW_E_LI_T * ( 1 / tE) * psympLI -> PW_ES_LI_T",
      "PW_ES_LI_T -> PW_ES_LI_T * ( 1 / tES) * (1 - psevLI * rsev) -> PW_IM_LI_T + incPM",
      "PW_ES_LI_T -> PW_ES_LI_T * ( 1 / tES) * psevLI * rsev -> PW_IS_LI_T + incPS",
      "PW_IM_LI_T -> PW_IM_LI_T * ( 1 / tIM) -> PW_S_HI",
      "PW_IS_LI_T -> PW_IS_LI_T * (1 - pIC) * ( 1 / tIS) -> PW_S_HI",
      "PW_IS_LI_T -> PW_IS_LI_T * pIC * ( 1 / tIS) -> IC",
      # HI
      "PW_E_HI -> PW_E_HI * ( 1 / tE) * (1 - psympHI) -> PW_EA_HI",
      "PW_EA_HI -> PW_EA_HI * ( 1 / tEA) -> PW_IA_HI + incPA",
      "PW_IA_HI -> PW_IA_HI * ( 1 / tIA) -> PW_S_HI",
      "PW_E_HI -> PW_E_HI * ( 1 / tE) * psympHI -> PW_ES_HI",
      "PW_ES_HI -> PW_ES_HI * ( 1 / tES) * (1 - psevHI * rsev) -> PW_IM_HI + incPM",
      "PW_ES_HI -> PW_ES_HI * ( 1 / tES) * psevHI * rsev -> PW_IS_HI + incPS",
      "PW_IM_HI -> PW_IM_HI * ( 1 / tIM) -> PW_S_HI",
      "PW_IS_HI -> PW_IS_HI * (1 - pIC) * ( 1 / tIS) -> PW_S_HI",
      "PW_IS_HI -> PW_IS_HI * pIC * ( 1 / tIS) -> IC",
      "PW_E_HI_T -> PW_E_HI_T * ( 1 / tE) * (1 - psympHI) -> PW_EA_HI_T",
      "PW_EA_HI_T -> PW_EA_HI_T * ( 1 / tEA) -> PW_IA_HI_T + incPA",
      "PW_IA_HI_T -> PW_IA_HI_T * ( 1 / tIA) -> PW_S_HI",
      "PW_E_HI_T -> PW_E_HI_T * ( 1 / tE) * psympHI -> PW_ES_HI_T",
      "PW_ES_HI_T -> PW_ES_HI_T * ( 1 / tES) * (1 - psevHI * rsev) -> PW_IM_HI_T + incPM",
      "PW_ES_HI_T -> PW_ES_HI_T * ( 1 / tES) * psevHI * rsev -> PW_IS_HI_T + incPS",
      "PW_IM_HI_T -> PW_IM_HI_T * ( 1 / tIM) -> PW_S_HI",
      "PW_IS_HI_T -> PW_IS_HI_T * (1 - pIC) * ( 1 / tIS) -> PW_S_HI",
      "PW_IS_HI_T -> PW_IS_HI_T * pIC * ( 1 / tIS) -> IC",
      ### Immunity waning
      "PW_S_HI -> PW_S_HI * (1 / tHI) -> PW_S_LI",
      "PW_S_HI_T -> PW_S_HI_T * (1 / tHI) -> PW_S_LI_T",
      "PW_S_LI -> PW_S_LI * (1 / tLI) -> PW_S_NI",
      "PW_S_LI_T -> PW_S_LI_T * (1 / tLI) -> PW_S_NI_T",
      ### Immunity gain
      "PW_S_NI -> PW_S_NI * hNI2LI -> PW_S_LI",
      "PW_S_NI_T -> PW_S_NI_T * hNI2LI -> PW_S_LI_T",
      "PW_S_LI -> PW_S_LI * hLI2HI -> PW_S_HI",
      "PW_S_LI_T -> PW_S_LI_T * hLI2HI -> PW_S_HI_T",
      ### Exit
      ## No immunity
      "PW_S_NI -> PW_S_NI * ( 1 / tLS) -> @",
      "PW_E_NI -> PW_E_NI * ( 1 / tLS) -> @",
      "PW_EA_NI -> PW_EA_NI * ( 1 / tLS) -> @",
      "PW_ES_NI -> PW_ES_NI * ( 1 / tLS) -> @",
      "PW_IA_NI -> PW_IA_NI * ( 1 / tLS) -> @",
      "PW_IM_NI -> PW_IM_NI * ( 1 / tLS) -> @",
      "PW_IS_NI -> PW_IS_NI * ( 1 / tLS) -> @",
      #
      "PW_S_NI_T -> PW_S_NI_T * ( 1 / tLS) -> @",
      "PW_E_NI_T -> PW_E_NI_T * ( 1 / tLS) -> @",
      "PW_EA_NI_T -> PW_EA_NI_T * ( 1 / tLS) -> @",
      "PW_ES_NI_T -> PW_ES_NI_T * ( 1 / tLS) -> @",
      "PW_IA_NI_T -> PW_IA_NI_T * ( 1 / tLS) -> @",
      "PW_IM_NI_T -> PW_IM_NI_T * ( 1 / tLS) -> @",
      "PW_IS_NI_T -> PW_IS_NI_T * ( 1 / tLS) -> @",
      ## Low immunity
      "PW_S_LI -> PW_S_LI * ( 1 / tLS) -> @",
      "PW_E_LI -> PW_E_LI * ( 1 / tLS) -> @",
      "PW_EA_LI -> PW_EA_LI * ( 1 / tLS) -> @",
      "PW_ES_LI -> PW_ES_LI * ( 1 / tLS) -> @",
      "PW_IA_LI -> PW_IA_LI * ( 1 / tLS) -> @",
      "PW_IM_LI -> PW_IM_LI * ( 1 / tLS) -> @",
      "PW_IS_LI -> PW_IS_LI * ( 1 / tLS) -> @",
      #
      "PW_S_LI_T -> PW_S_LI_T * ( 1 / tLS) -> @",
      "PW_E_LI_T -> PW_E_LI_T * ( 1 / tLS) -> @",
      "PW_EA_LI_T -> PW_EA_LI_T * ( 1 / tLS) -> @",
      "PW_ES_LI_T -> PW_ES_LI_T * ( 1 / tLS) -> @",
      "PW_IA_LI_T -> PW_IA_LI_T * ( 1 / tLS) -> @",
      "PW_IM_LI_T -> PW_IM_LI_T * ( 1 / tLS) -> @",
      "PW_IS_LI_T -> PW_IS_LI_T * ( 1 / tLS) -> @",
      ## High immunity
      "PW_S_HI -> PW_S_HI * ( 1 / tLS) -> @",
      "PW_E_HI -> PW_E_HI * ( 1 / tLS) -> @",
      "PW_EA_HI -> PW_EA_HI * ( 1 / tLS) -> @",
      "PW_ES_HI -> PW_ES_HI * ( 1 / tLS) -> @",
      "PW_IA_HI -> PW_IA_HI * ( 1 / tLS) -> @",
      "PW_IM_HI -> PW_IM_HI * ( 1 / tLS) -> @",
      "PW_IS_HI -> PW_IS_HI * ( 1 / tLS) -> @",
      #
      "PW_S_HI_T -> PW_S_HI_T * ( 1 / tLS) -> @",
      "PW_E_HI_T -> PW_E_HI_T * ( 1 / tLS) -> @",
      "PW_EA_HI_T -> PW_EA_HI_T * ( 1 / tLS) -> @",
      "PW_ES_HI_T -> PW_ES_HI_T * ( 1 / tLS) -> @",
      "PW_IA_HI_T -> PW_IA_HI_T * ( 1 / tLS) -> @",
      "PW_IM_HI_T -> PW_IM_HI_T * ( 1 / tLS) -> @",
      "PW_IS_HI_T -> PW_IS_HI_T * ( 1 / tLS) -> @",
      ####
      #### Iso and IC
      ####
      "ISO -> ISO * ( 1 / tLS) -> @",
      "ISO -> ISO * ( 1 / tISO) -> PW_S_HI",
      "IC -> IC * ( 1 / tLS) -> @",
      "IC -> IC * pdieIC -> @",
      "IC -> IC * (1 - pdieIC) * ( 1 / tIC) -> PW_S_HI",
      ######
      ###### Healthcare professionals
      ######
      ### Immunity waning
      "H_S_HI -> H_S_HI * (1 / tHI) -> H_S_LI",
      "H_S_HI_T -> H_S_HI_T * (1 / tHI) -> H_S_LI_T",
      "H_S_LI -> H_S_LI * (1 / tLI) -> H_S_NI",
      "H_S_LI_T -> H_S_LI_T * (1 / tLI) -> H_S_NI_T",
      ### Immunity gain
      "H_S_NI -> H_S_NI * hNI2LI -> H_S_LI",
      "H_S_NI_T -> H_S_NI_T * hNI2LI -> H_S_LI_T",
      "H_S_LI -> H_S_LI * hLI2HI -> H_S_HI",
      "H_S_LI_T -> H_S_LI_T * hLI2HI -> H_S_HI_T",
      #  infection in community
      paste("H_S_NI -> H_S_NI * hinc -> H_E_NI + infHout"),
      paste("H_S_NI_T -> H_S_NI_T * hinc -> H_E_NI_T + infHout"),
      paste("H_S_LI -> H_S_LI * hinc * rinfLI-> H_E_LI + infHout"),
      paste("H_S_LI_T -> H_S_LI_T * hinc * rinfLI -> H_E_LI_T + infHout"),
      paste("H_S_HI -> H_S_HI * hinc * rinfHI -> H_E_HI + infHout"),
      paste("H_S_HI_T -> H_S_HI_T * hinc * rinfHI -> H_E_HI_T + infHout"),
      ###
      ### Disease cycle
      ###
      # NI
      "H_E_NI -> H_E_NI * ( 1 / tE) * (1 - psympNI * rsymp) -> H_EA_NI",
      "H_EA_NI -> H_EA_NI * ( 1 / tEA) -> H_IA_NI + incHA",
      "H_IA_NI -> H_IA_NI * ( 1 / tIA) -> H_S_HI",
      "H_E_NI -> H_E_NI * ( 1 / tE) * psympNI * rsymp -> H_ES_NI",
      "H_ES_NI -> H_ES_NI * ( 1 / tES) * (1 - psevNI) -> H_IM_NI + incHM",
      "H_ES_NI -> H_ES_NI * ( 1 / tES) * psevNI -> H_IS_NI + incHS",
      "H_IM_NI -> H_IM_NI * (1 - pSL) * ( 1 / tIM) -> H_S_HI",
      "H_IM_NI -> H_IM_NI * pSL * ( 1 / tIM) -> SL",
      "H_IS_NI -> H_IS_NI * (1 - pESL) * ( 1 / tIS) -> H_S_HI",
      "H_IS_NI -> H_IS_NI * pESL * ( 1 / tIS) -> ESL",
      #
      "H_E_NI_T -> H_E_NI_T * ( 1 / tE) * (1 - psympNI * rsymp) -> H_EA_NI_T",
      "H_EA_NI_T -> H_EA_NI_T * ( 1 / tEA) -> H_IA_NI_T + incHA",
      "H_IA_NI_T -> H_IA_NI_T * ( 1 / tIA) -> H_S_HI",
      "H_E_NI_T -> H_E_NI_T * ( 1 / tE) * psympNI * rsymp -> H_ES_NI_T",
      "H_ES_NI_T -> H_ES_NI_T * ( 1 / tES) * (1 - psevNI) -> H_IM_NI_T + incHM",
      "H_ES_NI_T -> H_ES_NI_T * ( 1 / tES) * psevNI -> H_IS_NI_T + incHS",
      "H_IM_NI_T -> H_IM_NI_T * (1 - pSL) * ( 1 / tIM) -> H_S_HI_T",
      "H_IM_NI_T -> H_IM_NI_T * pSL * ( 1 / tIM) -> SL",
      "H_IS_NI_T -> H_IS_NI_T * (1 - pESL) * ( 1 / tIS) -> H_S_HI_T",
      "H_IS_NI_T -> H_IS_NI_T * pESL * ( 1 / tIS) -> ESL",
      # LI
      "H_E_LI -> H_E_LI * ( 1 / tE) * (1 - psympLI * rsymp) -> H_EA_LI",
      "H_EA_LI -> H_EA_LI * ( 1 / tEA) -> H_IA_LI + incHA",
      "H_IA_LI -> H_IA_LI * ( 1 / tIA) -> H_S_HI",
      "H_E_LI -> H_E_LI * ( 1 / tE) * psympLI * rsymp -> H_ES_LI",
      "H_ES_LI -> H_ES_LI * ( 1 / tES) * (1 - psevLI) -> H_IM_LI + incHM",
      "H_ES_LI -> H_ES_LI * ( 1 / tES) * psevLI -> H_IS_LI + incHS",
      "H_IM_LI -> H_IM_LI * (1 - pSL) * ( 1 / tIM) -> H_S_HI",
      "H_IM_LI -> H_IM_LI * pSL * ( 1 / tIM) -> SL",
      "H_IS_LI -> H_IS_LI * (1 - pESL) * ( 1 / tIS) -> H_S_HI",
      "H_IS_LI -> H_IS_LI * pESL * ( 1 / tIS) -> ESL",
      #
      "H_E_LI_T -> H_E_LI_T * ( 1 / tE) * (1 - psympLI * rsymp) -> H_EA_LI_T",
      "H_EA_LI_T -> H_EA_LI_T * ( 1 / tEA) -> H_IA_LI_T + incHA",
      "H_IA_LI_T -> H_IA_LI_T * ( 1 / tIA) -> H_S_HI",
      "H_E_LI_T -> H_E_LI_T * ( 1 / tE) * psympLI * rsymp -> H_ES_LI_T",
      "H_ES_LI_T -> H_ES_LI_T * ( 1 / tES) * (1 - psevLI) -> H_IM_LI_T + incHM",
      "H_ES_LI_T -> H_ES_LI_T * ( 1 / tES) * psevLI -> H_IS_LI_T + incHS",
      "H_IM_LI_T -> H_IM_LI_T * (1 - pSL) * ( 1 / tIM) -> H_S_HI_T",
      "H_IM_LI_T -> H_IM_LI_T * pSL * ( 1 / tIM) -> SL",
      "H_IS_LI_T -> H_IS_LI_T * (1 - pESL) * ( 1 / tIS) -> H_S_HI_T",
      "H_IS_LI_T -> H_IS_LI_T * pESL * ( 1 / tIS) -> ESL",
      # HI
      "H_E_HI -> H_E_HI * ( 1 / tE) * (1 - psympHI * rsymp) -> H_EA_HI",
      "H_EA_HI -> H_EA_HI * ( 1 / tEA) -> H_IA_HI + incHA",
      "H_IA_HI -> H_IA_HI * ( 1 / tIA) -> H_S_HI",
      "H_E_HI -> H_E_HI * ( 1 / tE) * psympHI * rsymp -> H_ES_HI",
      "H_ES_HI -> H_ES_HI * ( 1 / tES) * (1 - psevHI) -> H_IM_HI + incHM",
      "H_ES_HI -> H_ES_HI * ( 1 / tES) * psevHI -> H_IS_HI + incHS",
      "H_IM_HI -> H_IM_HI * (1 - pSL) * ( 1 / tIM) -> H_S_HI",
      "H_IM_HI -> H_IM_HI * pSL * ( 1 / tIM) -> SL",
      "H_IS_HI -> H_IS_HI * (1 - pESL) * ( 1 / tIS) -> H_S_HI",
      "H_IS_HI -> H_IS_HI * pESL * ( 1 / tIS) -> ESL",
      #
      "H_E_HI_T -> H_E_HI_T * ( 1 / tE) * (1 - psympHI * rsymp) -> H_EA_HI_T",
      "H_EA_HI_T -> H_EA_HI_T * ( 1 / tEA) -> H_IA_HI_T + incHA",
      "H_IA_HI_T -> H_IA_HI_T * ( 1 / tIA) -> H_S_HI",
      "H_E_HI_T -> H_E_HI_T * ( 1 / tE) * psympHI * rsymp -> H_ES_HI_T",
      "H_ES_HI_T -> H_ES_HI_T * ( 1 / tES) * (1 - psevHI) -> H_IM_HI_T + incHM",
      "H_ES_HI_T -> H_ES_HI_T * ( 1 / tES) * psevHI -> H_IS_HI_T + incHS",
      "H_IM_HI_T -> H_IM_HI_T * (1 - pSL) * ( 1 / tIM) -> H_S_HI_T",
      "H_IM_HI_T -> H_IM_HI_T * pSL * ( 1 / tIM) -> SL",
      "H_IS_HI_T -> H_IS_HI_T * (1 - pESL) * ( 1 / tIS) -> H_S_HI_T",
      "H_IS_HI_T -> H_IS_HI_T * pESL * ( 1 / tIS) -> ESL",
      ###
      ### Return from SL and ESL
      ###
      ## SL
      "SL -> SL *  ( 1 / tSL) -> H_S_HI",
      ## ESL
      "ESL -> ESL *  ( 1 / tESL) -> H_S_HI",
      ###
      ### Tests
      ###
      ## NI
      # untested to tested
      "H_S_NI -> H_S_NI * ptestHNI * (1 / tbtwtestH) -> H_S_NI_T",
      "H_E_NI -> H_E_NI * ptestHNI * (1 / tbtwtestH) -> H_E_NI_T",
      "H_EA_NI -> H_EA_NI * ptestHNI * (1 / tbtwtestH) -> H_EA_NI_T",
      "H_ES_NI -> H_ES_NI * ptestHNI * (1 / tbtwtestH) -> H_ES_NI_T",
      "H_IA_NI -> H_IA_NI * ptestHNI * (1 / tbtwtestH) -> H_IA_NI_T",
      "H_IM_NI -> H_IM_NI * ptestHsymp * (1 / tbeftestHsymp) -> H_IM_NI_T",
      "H_IS_NI -> H_IS_NI * ptestHsymp * (1 / tbeftestHsymp) -> H_IS_NI_T",
      # tested to untested (negative test and positive but stay)
      "H_S_NI_T -> H_S_NI_T * speH * ( 1 / ttestHW) -> H_S_NI + nTestH",
      "H_E_NI_T -> H_E_NI_T * (1 - senH) * ( 1 / ttestHW) -> H_E_NI + nTestH",
      "H_EA_NI_T -> H_EA_NI_T * (1 - senH) * ( 1 / ttestHW) -> H_EA_NI + nTestH",
      "H_ES_NI_T -> H_ES_NI_T * (1 - senH) * ( 1 / ttestHW) -> H_ES_NI + nTestH",
      "H_IA_NI_T -> H_IA_NI_T * (1 - senH) * ( 1 / ttestHW) -> H_IA_NI + nTestH",
      "H_IM_NI_T -> H_IM_NI_T * (1 - sensymp) * ( 1 / ttestsymp) -> H_IM_NI + nTestH",
      "H_IS_NI_T -> H_IS_NI_T * (1 - sensymp) * ( 1 / ttestsymp) -> H_IS_NI + nTestH",
      # tested to sick leave (positive test)
      "H_S_NI_T -> H_S_NI_T * (1 - speH) * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_E_NI_T -> H_E_NI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_EA_NI_T -> H_EA_NI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_ES_NI_T -> H_ES_NI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_IA_NI_T -> H_IA_NI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_IM_NI_T -> H_IM_NI_T * sensymp * pSLT * ( 1 / ttestsymp) -> SL + nTestH",
      "H_IS_NI_T -> H_IS_NI_T * sensymp * pSLT * ( 1 / ttestsymp) -> ESL + nTestH",
      ## LI
      # untested to tested
      "H_S_LI -> H_S_LI * ptestHLI * (1 / tbtwtestH) -> H_S_LI_T",
      "H_E_LI -> H_E_LI * ptestHLI * (1 / tbtwtestH) -> H_E_LI_T",
      "H_EA_LI -> H_EA_LI * ptestHLI * (1 / tbtwtestH) -> H_EA_LI_T",
      "H_ES_LI -> H_ES_LI * ptestHLI * (1 / tbtwtestH) -> H_ES_LI_T",
      "H_IA_LI -> H_IA_LI * ptestHLI * (1 / tbtwtestH) -> H_IA_LI_T",
      "H_IM_LI -> H_IM_LI * ptestHsymp * (1 / tbeftestHsymp) -> H_IM_LI_T",
      "H_IS_LI -> H_IS_LI * ptestHsymp * (1 / tbeftestHsymp) -> H_IS_LI_T",
      # tested to untested (negative test and positive but stay)
      "H_S_LI_T -> H_S_LI_T * speH * ( 1 / ttestHW) -> H_S_LI + nTestH",
      "H_E_LI_T -> H_E_LI_T * (1 - senH) * ( 1 / ttestHW) -> H_E_LI + nTestH",
      "H_EA_LI_T -> H_EA_LI_T * (1 - senH) * ( 1 / ttestHW) -> H_EA_LI + nTestH",
      "H_ES_LI_T -> H_ES_LI_T * (1 - senH) * ( 1 / ttestHW) -> H_ES_LI + nTestH",
      "H_IA_LI_T -> H_IA_LI_T * (1 - senH) * ( 1 / ttestHW) -> H_IA_LI + nTestH",
      "H_IM_LI_T -> H_IM_LI_T * (1 - sensymp) * ( 1 / ttestsymp) -> H_IM_LI + nTestH",
      "H_IS_LI_T -> H_IS_LI_T * (1 - sensymp) * ( 1 / ttestsymp) -> H_IS_LI + nTestH",
      # tested to sick leave (positive test)
      "H_S_LI_T -> H_S_LI_T * (1 - speH) * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_E_LI_T -> H_E_LI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_EA_LI_T -> H_EA_LI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_ES_LI_T -> H_ES_LI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_IA_LI_T -> H_IA_LI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_IM_LI_T -> H_IM_LI_T * sensymp * pSLT * ( 1 / ttestsymp) -> SL + nTestH",
      "H_IS_LI_T -> H_IS_LI_T * sensymp * pSLT * ( 1 / ttestsymp) -> ESL + nTestH",
      ## HI
      # untested to tested
      "H_S_HI -> H_S_HI * ptestHHI * (1 / tbtwtestH) -> H_S_HI_T",
      "H_E_HI -> H_E_HI * ptestHHI * (1 / tbtwtestH) -> H_E_HI_T",
      "H_EA_HI -> H_EA_HI * ptestHHI * (1 / tbtwtestH) -> H_EA_HI_T",
      "H_ES_HI -> H_ES_HI * ptestHHI * (1 / tbtwtestH) -> H_ES_HI_T",
      "H_IA_HI -> H_IA_HI * ptestHHI * (1 / tbtwtestH) -> H_IA_HI_T",
      "H_IM_HI -> H_IM_HI * ptestHsymp * (1 / tbeftestHsymp) -> H_IM_HI_T",
      "H_IS_HI -> H_IS_HI * ptestHsymp * (1 / tbeftestHsymp) -> H_IS_HI_T",
      # tested to untested (negative test and positive but stay)
      "H_S_HI_T -> H_S_HI_T * speH * ( 1 / ttestHW) -> H_S_HI + nTestH",
      "H_E_HI_T -> H_E_HI_T * (1 - senH) * ( 1 / ttestHW) -> H_E_HI + nTestH",
      "H_EA_HI_T -> H_EA_HI_T * (1 - senH) * ( 1 / ttestHW) -> H_EA_HI + nTestH",
      "H_ES_HI_T -> H_ES_HI_T * (1 - senH) * ( 1 / ttestHW) -> H_ES_HI + nTestH",
      "H_IA_HI_T -> H_IA_HI_T * (1 - senH) * ( 1 / ttestHW) -> H_IA_HI + nTestH",
      "H_IM_HI_T -> H_IM_HI_T * (1 - sensymp) * ( 1 / ttestsymp) -> H_IM_HI + nTestH",
      "H_IS_HI_T -> H_IS_HI_T * (1 - sensymp) * ( 1 / ttestsymp) -> H_IS_HI + nTestH",
      # tested to sick leave (positive test)
      "H_S_HI_T -> H_S_HI_T * (1 - speH) * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_E_HI_T -> H_E_HI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_EA_HI_T -> H_EA_HI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_ES_HI_T -> H_ES_HI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_IA_HI_T -> H_IA_HI_T * senH * pSLT * ( 1 / ttestHW) -> SL + nTestH",
      "H_IM_HI_T -> H_IM_HI_T * sensymp * pSLT * ( 1 / ttestsymp) -> SL + nTestH",
      "H_IS_HI_T -> H_IS_HI_T * sensymp * pSLT * ( 1 / ttestsymp) -> ESL + nTestH"
    )

  # Add admission - SA epidemiological events - HCWS infections
  if(isTRUE(SA))
    transitions %<>% c(.,
                       c(
                         ####
                         #### screening area
                         ####
                         ### New patient (if there is an available bed)
                         ## Non Immune
                         # Susceptible
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) * (1 − prev) : 0 -> PSA_S_NI + nadm"),
                         # Exposed
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rE : 0 -> PSA_E_NI + nadm + admInf"),
                         # Exposed infectious future asymptomatic
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rEA : 0 -> PSA_EA_NI + nadm + admInf"),
                         # Exposed infectious future symptomatic
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rES : 0 -> PSA_ES_NI + nadm + admInf"),
                         # Infectious asymptomatic
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rIA : 0 -> PSA_IA_NI + nadm + admInf"),
                         # Infectious with mild symptoms
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rIM : 0 -> PSA_IM_NI + nadm + admInf"),
                         # Infectious with severe symptoms
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rIS : 0 -> PSA_IS_NI + nadm + admInf"),
                         ## Partially Immune
                         # Susceptible
                         paste("@ ->", SPACE ,"? pLI * (1 − prev) : 0 -> PSA_S_LI + nadm"),
                         # Exposed
                         paste("@ ->", SPACE ,"? pLI *  prev * rE : 0 -> PSA_E_LI + nadm + admInf"),
                         # Exposed infectious future asymptomatic
                         paste("@ ->", SPACE ,"? pLI *  prev * rEA : 0 -> PSA_EA_LI + nadm + admInf"),
                         # Exposed infectious future symptomatic
                         paste("@ ->", SPACE ,"? pLI *  prev * rES : 0 -> PSA_ES_LI + nadm + admInf"),
                         # Infectious asymptomatic
                         paste("@ ->", SPACE ,"? pLI *  prev * rIA : 0 -> PSA_IA_LI + nadm + admInf"),
                         # Infectious with mild symptoms
                         paste("@ ->", SPACE ,"? pLI *  prev * rIM : 0 -> PSA_IM_LI + nadm + admInf"),
                         # Infectious with severe symptoms
                         paste("@ ->", SPACE ,"? pLI *  prev * rIS : 0 -> PSA_IS_LI + nadm + admInf"),
                         ## Fully Immune
                         # Susceptible
                         paste("@ ->", SPACE ,"? pHI * (1 − prev) : 0 -> PSA_S_HI + nadm"),
                         # Exposed
                         paste("@ ->", SPACE ,"? pHI *  prev * rE : 0 -> PSA_E_HI + nadm + admInf"),
                         # Exposed infectious future asymptomatic
                         paste("@ ->", SPACE ,"? pHI *  prev * rEA : 0 -> PSA_EA_HI + nadm + admInf"),
                         # Exposed infectious future symptomatic
                         paste("@ ->", SPACE ,"? pHI *  prev * rES : 0 -> PSA_ES_HI + nadm + admInf"),
                         # Infectious asymptomatic
                         paste("@ ->", SPACE ,"? pHI *  prev * rIA : 0 -> PSA_IA_HI + nadm + admInf"),
                         # Infectious with mild symptoms
                         paste("@ ->", SPACE ,"? pHI *  prev * rIM : 0 -> PSA_IM_HI + nadm + admInf"),
                         # Infectious with severe symptoms
                         paste("@ ->", SPACE ,"? pHI *  prev * rIS : 0 -> PSA_IS_HI + nadm + admInf"),
                         # Admission
                         ####
                         ### Test
                         ## No immunity
                         "PSA_S_NI -> PSA_S_NI * ptestPSANI * ( 1 / tSA) -> PSA_S_NI_T",
                         "PSA_E_NI -> PSA_E_NI * ptestPSANI * ( 1 / tSA) -> PSA_E_NI_T",
                         "PSA_EA_NI -> PSA_EA_NI * ptestPSANI * ( 1 / tSA) -> PSA_EA_NI_T",
                         "PSA_ES_NI -> PSA_ES_NI * ptestPSANI * ( 1 / tSA) -> PSA_ES_NI_T",
                         "PSA_IA_NI -> PSA_IA_NI * ptestPSANI * ( 1 / tSA) -> PSA_IA_NI_T",
                         "PSA_IM_NI -> PSA_IM_NI * ptestPSAsymp * ( 1 / tSA) -> PSA_IM_NI_T",
                         "PSA_IS_NI -> PSA_IS_NI * ptestPSAsymp * ( 1 / tSA) -> PSA_IS_NI_T",
                         # "PSA_IS_NI -> PSA_IS_NI * ptestPSAsymp * (1 - pIC) * ( 1 / tSA) -> PSA_IS_NI_T",
                         # "PSA_IS_NI -> PSA_IS_NI * ptestPSAsymp * pIC -> IC",
                         ## Low immunity
                         "PSA_S_LI -> PSA_S_LI * ptestPSALI * ( 1 / tSA) -> PSA_S_LI_T",
                         "PSA_E_LI -> PSA_E_LI * ptestPSALI * ( 1 / tSA) -> PSA_E_LI_T",
                         "PSA_EA_LI -> PSA_EA_LI * ptestPSALI * ( 1 / tSA) -> PSA_EA_LI_T",
                         "PSA_ES_LI -> PSA_ES_LI * ptestPSALI * ( 1 / tSA) -> PSA_ES_LI_T",
                         "PSA_IA_LI -> PSA_IA_LI * ptestPSALI * ( 1 / tSA) -> PSA_IA_LI_T",
                         "PSA_IM_LI -> PSA_IM_LI * ptestPSAsymp * ( 1 / tSA) -> PSA_IM_LI_T",
                         "PSA_IS_LI -> PSA_IS_LI * ptestPSAsymp * ( 1 / tSA) -> PSA_IS_LI_T",
                         # "PSA_IS_LI -> PSA_IS_LI * ptestPSAsymp * (1 - pIC) * ( 1 / tSA) -> PSA_IS_LI_T",
                         # "PSA_IS_LI -> PSA_IS_LI * ptestPSAsymp * pIC -> IC",
                         ## High immunity
                         "PSA_S_HI -> PSA_S_HI * ptestPSAHI * ( 1 / tSA) -> PSA_S_HI_T",
                         "PSA_E_HI -> PSA_E_HI * ptestPSAHI * ( 1 / tSA) -> PSA_E_HI_T",
                         "PSA_EA_HI -> PSA_EA_HI * ptestPSAHI * ( 1 / tSA) -> PSA_EA_HI_T",
                         "PSA_ES_HI -> PSA_ES_HI * ptestPSAHI * ( 1 / tSA) -> PSA_ES_HI_T",
                         "PSA_IA_HI -> PSA_IA_HI * ptestPSAHI * ( 1 / tSA) -> PSA_IA_HI_T",
                         "PSA_IM_HI -> PSA_IM_HI * ptestPSAsymp * ( 1 / tSA) -> PSA_IM_HI_T",
                         "PSA_IS_HI -> PSA_IS_HI * ptestPSAsymp * ( 1 / tSA) -> PSA_IS_HI_T",
                         # "PSA_IS_HI -> PSA_IS_HI * ptestPSAsymp * (1 - pIC) * ( 1 / tSA) -> PSA_IS_HI_T",
                         # "PSA_IS_HI -> PSA_IS_HI * ptestPSAsymp * pIC * ( 1 / tSA) -> IC",
                         ### Admission
                         ## No immunity
                         # non tested to ward
                         "PSA_S_NI -> PSA_S_NI * (1 - ptestPSANI) * ( 1 / tSA) -> PW_S_NI",
                         "PSA_E_NI -> PSA_E_NI * (1 − ptestPSANI) * ( 1 / tSA) -> PW_E_NI",
                         "PSA_EA_NI -> PSA_EA_NI * (1 − ptestPSANI) * ( 1 / tSA) -> PW_EA_NI",
                         "PSA_ES_NI -> PSA_ES_NI * (1 − ptestPSANI) * ( 1 / tSA) -> PW_ES_NI",
                         "PSA_IA_NI -> PSA_IA_NI * (1 − ptestPSANI) * ( 1 / tSA) -> PW_IA_NI",
                         "PSA_IM_NI -> PSA_IM_NI * (1 − ptestPSAsymp) * ( 1 / tSA) -> PW_IM_NI",
                         "PSA_IS_NI -> PSA_IS_NI * (1 − ptestPSAsymp) * ( 1 / tSA) -> PW_IS_NI",
                         # tested to untested (negative test result or positive test result without confinement)
                         "PSA_S_NI_T -> PSA_S_NI_T * (speSA + (1-speSA) * (1 - pISO)) * ( 1 / ttestSA) -> PW_S_NI + nTestP",
                         "PSA_E_NI_T -> PSA_E_NI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_E_NI + nTestP",
                         "PSA_EA_NI_T -> PSA_EA_NI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_EA_NI + nTestP",
                         "PSA_ES_NI_T -> PSA_ES_NI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_ES_NI + nTestP",
                         "PSA_IA_NI_T -> PSA_IA_NI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_IA_NI + nTestP",
                         "PSA_IM_NI_T -> PSA_IM_NI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IM_NI + nTestP",
                         "PSA_IS_NI_T -> PSA_IS_NI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IS_NI + nTestP",
                         # tested to confinement
                         "PSA_S_NI_T -> PSA_S_NI_T * (1 - speSA) * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_E_NI_T -> PSA_E_NI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_EA_NI_T -> PSA_EA_NI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_ES_NI_T -> PSA_ES_NI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_IA_NI_T -> PSA_IA_NI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_IM_NI_T -> PSA_IM_NI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
                         "PSA_IS_NI_T -> PSA_IS_NI_T * sensymp * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
                         ## Low immunity
                         # non tested to ward
                         "PSA_S_LI -> PSA_S_LI * (1 - ptestPSALI) * ( 1 / tSA) -> PW_S_LI",
                         "PSA_E_LI -> PSA_E_LI * (1 − ptestPSALI) * ( 1 / tSA) -> PW_E_LI",
                         "PSA_EA_LI -> PSA_EA_LI * (1 − ptestPSALI) * ( 1 / tSA) -> PW_EA_LI",
                         "PSA_ES_LI -> PSA_ES_LI * (1 − ptestPSALI) * ( 1 / tSA) -> PW_ES_LI",
                         "PSA_IA_LI -> PSA_IA_LI * (1 − ptestPSALI) * ( 1 / tSA) -> PW_IA_LI",
                         "PSA_IM_LI -> PSA_IM_LI * (1 − ptestPSAsymp) * ( 1 / tSA) -> PW_IM_LI",
                         "PSA_IS_LI -> PSA_IS_LI * (1 − ptestPSAsymp) * ( 1 / tSA) -> PW_IS_LI",
                         # tested to ward
                         "PSA_S_LI_T -> PSA_S_LI_T * (speSA + (1-speSA) * (1 - pISO)) * ( 1 / ttestSA) -> PW_S_LI + nTestP",
                         "PSA_E_LI_T -> PSA_E_LI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_E_LI + nTestP",
                         "PSA_EA_LI_T -> PSA_EA_LI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_EA_LI + nTestP",
                         "PSA_ES_LI_T -> PSA_ES_LI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_ES_LI + nTestP",
                         "PSA_IA_LI_T -> PSA_IA_LI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_IA_LI + nTestP",
                         "PSA_IM_LI_T -> PSA_IM_LI_T * ((1 - sensymp) + sensymp * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IM_LI + nTestP",
                         "PSA_IS_LI_T -> PSA_IS_LI_T * ((1 - sensymp) + sensymp * (1 - pISO))  * ( 1 / ttestsymp) -> PW_IS_LI + nTestP",
                         # tested to confinement or IC
                         "PSA_S_LI_T -> PSA_S_LI_T * (1 - speSA) * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_E_LI_T -> PSA_E_LI_T * senSA * ( 1 / ttestSA) * pISO  -> ISO + nTestP",
                         "PSA_EA_LI_T -> PSA_EA_LI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_ES_LI_T -> PSA_ES_LI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_IA_LI_T -> PSA_IA_LI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_IM_LI_T -> PSA_IM_LI_T * senSA * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
                         "PSA_IS_LI_T -> PSA_IS_LI_T * senSA * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
                         ## High immunity
                         # non tested to ward
                         "PSA_S_HI -> PSA_S_HI * (1 - ptestPSAHI) * ( 1 / tSA) -> PW_S_HI",
                         "PSA_E_HI -> PSA_E_HI * (1 − ptestPSAHI) * ( 1 / tSA) -> PW_E_HI",
                         "PSA_EA_HI -> PSA_EA_HI * (1 − ptestPSAHI) * ( 1 / tSA) -> PW_EA_HI",
                         "PSA_ES_HI -> PSA_ES_HI * (1 − ptestPSAHI) * ( 1 / tSA) -> PW_ES_HI",
                         "PSA_IA_HI -> PSA_IA_HI * (1 − ptestPSAHI) * ( 1 / tSA) -> PW_IA_HI",
                         "PSA_IM_HI -> PSA_IM_HI * (1 − ptestPSAsymp) * ( 1 / tSA) -> PW_IM_HI",
                         "PSA_IS_HI -> PSA_IS_HI * (1 − ptestPSAsymp) *  ( 1 / tSA) -> PW_IS_HI",
                         # tested to ward
                         "PSA_S_HI_T -> PSA_S_HI_T * ( 1 / ttestSA)  * (speSA + (1 - speSA) * (1 - pISO)) -> PW_S_HI + nTestP",
                         "PSA_E_HI_T -> PSA_E_HI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_E_HI + nTestP",
                         "PSA_EA_HI_T -> PSA_EA_HI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_EA_HI + nTestP",
                         "PSA_ES_HI_T -> PSA_ES_HI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_ES_HI + nTestP",
                         "PSA_IA_HI_T -> PSA_IA_HI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestSA) -> PW_IA_HI + nTestP",
                         "PSA_IM_HI_T -> PSA_IM_HI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IM_HI + nTestP",
                         "PSA_IS_HI_T -> PSA_IS_HI_T * ((1 - senSA) + senSA * (1 - pISO)) * ( 1 / ttestsymp) -> PW_IS_HI + nTestP",
                         # tested to confinement
                         "PSA_S_HI_T -> PSA_S_HI_T * (1 - speSA) * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_E_HI_T -> PSA_E_HI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_EA_HI_T -> PSA_EA_HI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_ES_HI_T -> PSA_ES_HI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_IA_HI_T -> PSA_IA_HI_T * senSA * ( 1 / ttestSA) * pISO -> ISO + nTestP",
                         "PSA_IM_HI_T -> PSA_IM_HI_T * senSA * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
                         "PSA_IS_HI_T -> PSA_IS_HI_T * senSA * ( 1 / ttestsymp) * pISO -> ISO + nTestP",
                         ### Infection
                         ## FIX ME: already tested can be tested positive while just infected
                         # no immunity
                         paste("PSA_S_NI -> ", PSAEMPTY,"? 0 : PSA_S_NI * ",lambdaPSA," -> PSA_E_NI + infP"),
                         paste("PSA_S_NI_T -> ", PSAEMPTY,"? 0 : PSA_S_NI_T * ",lambdaPSA," -> PSA_E_NI_T + infP"),
                         # low immunity
                         paste("PSA_S_LI -> ", PSAEMPTY,"? 0 : PSA_S_LI * ",lambdaPSA," -> PSA_E_LI + infP"),
                         paste("PSA_S_LI_T -> ", PSAEMPTY,"? 0 : PSA_S_LI_T * ",lambdaPSA," -> PSA_E_LI_T + infP"),
                         # high immunity
                         paste("PSA_S_HI -> ", PSAEMPTY,"? 0 : PSA_S_HI * ",lambdaPSA," -> PSA_E_HI + infP"),
                         paste("PSA_S_HI_T -> ", PSAEMPTY,"? 0 : PSA_S_HI_T * ",lambdaPSA," -> PSA_E_HI_T + infP"),
                         ##########
                         ####### Professionals
                         ##########
                         ### Infection
                         ###
                         # pinfH
                         paste("H_S_NI ->  (",nPSA," + ",nPW,") < 1 ? 0 : (", nPSA,") < 1  ?  H_S_NI *  pconta * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) : (", nPW,
                               ") < 1  ?  H_S_NI *  pconta * ((1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH, ")) * (1 - epsPHSA) * ctcHPSA * (",
                               nPSA,") / nH_SA * wpropInfPSAdest ) : H_S_NI *  pconta * ( (1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH,
                               ")) * ((1 - epsPHSA) * ctcHPSA * (", nPSA, ") / nH_SA * wpropInfPSAdest + (1 - epsPHW)  * ((ctcHPSA * (", nPSA,
                               ") + ctcHPW * (", nPW, "))/(", nH, ") - (ctcHPSA * (", nPSA, ") / nH_SA)) * wpropInfPWdest) +  ((", nH,
                               ") - nH_SA) / (", nH, ") * (1 - epsPHW) * (ctcHPSA * (", nPSA, ") + ctcHPW * (", nPW, "))/(", nH, ") * wpropInfPWdest) -> H_E_NI + infH"),
                         paste("H_S_NI_T ->  (",nPSA," + ",nPW,") < 1 ? 0 : (", nPSA,") < 1  ?  H_S_NI_T *  pconta * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) : (", nPW,
                               ") < 1  ?  H_S_NI_T *  pconta * ((1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH, ")) * (1 - epsPHSA) * ctcHPSA * (",
                               nPSA,") / nH_SA * wpropInfPSAdest ) : H_S_NI_T *  pconta * ( (1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH,
                               ")) * ((1 - epsPHSA) * ctcHPSA * (", nPSA, ") / nH_SA * wpropInfPSAdest + (1 - epsPHW)  * ((ctcHPSA * (", nPSA,
                               ") + ctcHPW * (", nPW, "))/(", nH, ") - (ctcHPSA * (", nPSA, ") / nH_SA)) * wpropInfPWdest) + ((", nH,
                               ") - nH_SA) / (", nH, ") * (1 - epsPHW) * (ctcHPSA * (", nPSA, ") + ctcHPW * (", nPW, "))/(", nH, ") * wpropInfPWdest) -> H_E_NI_T + infH"),
                         paste("H_S_LI ->  (",nPSA," + ",nPW,") < 1 ? 0 : (", nPSA,") < 1  ?  H_S_LI *  pconta * rinfLI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) : (", nPW,
                               ") < 1  ?  H_S_LI *  pconta * rinfLI * ((1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH, ")) * (1 - epsPHSA) * ctcHPSA * (",
                               nPSA,") / nH_SA * wpropInfPSAdest ) : H_S_LI *  pconta * rinfLI * ( (1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH,
                               ")) * ((1 - epsPHSA) * ctcHPSA * (", nPSA, ") / nH_SA * wpropInfPSAdest + (1 - epsPHW)  * ((ctcHPSA * (", nPSA,
                               ") + ctcHPW * (", nPW, "))/(", nH, ") - (ctcHPSA * (", nPSA, ") / nH_SA)) * wpropInfPWdest) + ((", nH,
                               ") - nH_SA) / (", nH, ") * (1 - epsPHW) * (ctcHPSA * (", nPSA, ") + ctcHPW * (", nPW, "))/(", nH, ") * wpropInfPWdest) -> H_E_LI + infH"),
                         paste("H_S_LI_T ->  (",nPSA," + ",nPW,") < 1 ? 0 : (", nPSA,") < 1  ?  H_S_LI_T *  pconta * rinfLI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) : (", nPW,
                               ") < 1  ?  H_S_LI_T *  pconta * rinfLI * ((1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH, ")) * (1 - epsPHSA) * ctcHPSA * (",
                               nPSA,") / nH_SA * wpropInfPSAdest ) : H_S_LI_T *  pconta * rinfLI * ( (1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH,
                               ")) * ((1 - epsPHSA) * ctcHPSA * (", nPSA, ") / nH_SA * wpropInfPSAdest + (1 - epsPHW)  * ((ctcHPSA * (", nPSA,
                               ") + ctcHPW * (", nPW, "))/(", nH, ") - (ctcHPSA * (", nPSA, ") / nH_SA)) * wpropInfPWdest) + ((", nH,
                               ") - nH_SA) / (", nH, ") * (1 - epsPHW) * (ctcHPSA * (", nPSA, ") + ctcHPW * (", nPW, "))/(", nH, ") * wpropInfPWdest) -> H_E_LI_T + infH"),
                         paste("H_S_HI ->  (",nPSA," + ",nPW,") < 1 ? 0 : (", nPSA,") < 1  ?  H_S_HI *  pconta * rinfHI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) : (", nPW,
                               ") < 1  ?  H_S_HI *  pconta * rinfHI * ((1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH, ")) * (1 - epsPHSA) * ctcHPSA * (",
                               nPSA,") / nH_SA * wpropInfPSAdest ) : H_S_HI *  pconta * rinfHI * ( (1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH,
                               ")) * ((1 - epsPHSA) * ctcHPSA * (", nPSA, ") / nH_SA * wpropInfPSAdest + (1 - epsPHW)  * ((ctcHPSA * (", nPSA,
                               ") + ctcHPW * (", nPW, "))/(", nH, ") - (ctcHPSA * (", nPSA, ") / nH_SA)) * wpropInfPWdest) + ((", nH,
                               ") - nH_SA) / (", nH, ") * (1 - epsPHW) * (ctcHPSA * (", nPSA, ") + ctcHPW * (", nPW, "))/(", nH, ") * wpropInfPWdest) -> H_E_HI + infH"),
                         paste("H_S_HI_T ->  (",nPSA," + ",nPW,") < 1 ? 0 : (", nPSA,") < 1  ?  H_S_HI_T *  pconta * rinfHI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) : (", nPW,
                               ") < 1  ?  H_S_HI_T *  pconta * rinfHI * ((1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH, ")) * (1 - epsPHSA) * ctcHPSA * (",
                               nPSA,") / nH_SA * wpropInfPSAdest ) : H_S_HI_T *  pconta * rinfHI * ( (1 - epsHHW) * ctcHH * wpropInfHdest + (nH_SA / (", nH,
                               ")) * ((1 - epsPHSA) * ctcHPSA * (", nPSA, ") / nH_SA * wpropInfPSAdest + (1 - epsPHW)  * ((ctcHPSA * (", nPSA,
                               ") + ctcHPW * (", nPW, "))/(", nH, ") - (ctcHPSA * (", nPSA, ") / nH_SA)) * wpropInfPWdest) + ((", nH,
                               ") - nH_SA) / (", nH, ") * (1 - epsPHW) * (ctcHPSA * (", nPSA, ") + ctcHPW * (", nPW, "))/(", nH, ") * wpropInfPWdest) -> H_E_HI_T + infH")
                       )
    ) else
  # Add admission - HCWS infections
    transitions %<>% c(.,
                       c(
                         ####
                         #### screening area
                         ####
                         ### New patient (if there is an available bed)
                         ## Non Immune
                         # Susceptible
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) * (1 − prev) : 0 -> PW_S_NI + nadm"),
                         # Exposed
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rE : 0 -> PW_E_NI + nadm + admInf"),
                         # Exposed infectious future asymptomatic
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rEA : 0 -> PW_EA_NI + nadm + admInf"),
                         # Exposed infectious future symptomatic
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rES : 0 -> PW_ES_NI + nadm + admInf"),
                         # Infectious asymptomatic
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rIA : 0 -> PW_IA_NI + nadm + admInf"),
                         # Infectious with mild symptoms
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rIM : 0 -> PW_IM_NI + nadm + admInf"),
                         # Infectious with severe symptoms
                         paste("@ ->", SPACE ,"? (1 − pLI − pHI) *  prev * rIS : 0 -> PW_IS_NI + nadm + admInf"),
                         ## Partially Immune
                         # Susceptible
                         paste("@ ->", SPACE ,"? pLI * (1 − prev) : 0 -> PW_S_LI + nadm"),
                         # Exposed
                         paste("@ ->", SPACE ,"? pLI *  prev * rE : 0 -> PW_E_LI + nadm + admInf"),
                         # Exposed infectious future asymptomatic
                         paste("@ ->", SPACE ,"? pLI *  prev * rEA : 0 -> PW_EA_LI + nadm + admInf"),
                         # Exposed infectious future symptomatic
                         paste("@ ->", SPACE ,"? pLI *  prev * rES : 0 -> PW_ES_LI + nadm + admInf"),
                         # Infectious asymptomatic
                         paste("@ ->", SPACE ,"? pLI *  prev * rIA : 0 -> PW_IA_LI + nadm + admInf"),
                         # Infectious with mild symptoms
                         paste("@ ->", SPACE ,"? pLI *  prev * rIM : 0 -> PW_IM_LI + nadm + admInf"),
                         # Infectious with severe symptoms
                         paste("@ ->", SPACE ,"? pLI *  prev * rIS : 0 -> PW_IS_LI + nadm + admInf"),
                         ## Fully Immune
                         # Susceptible
                         paste("@ ->", SPACE ,"? pHI * (1 − prev) : 0 -> PW_S_HI + nadm"),
                         # Exposed
                         paste("@ ->", SPACE ,"? pHI *  prev * rE : 0 -> PW_E_HI + nadm + admInf"),
                         # Exposed infectious future asymptomatic
                         paste("@ ->", SPACE ,"? pHI *  prev * rEA : 0 -> PW_EA_HI + nadm + admInf"),
                         # Exposed infectious future symptomatic
                         paste("@ ->", SPACE ,"? pHI *  prev * rES : 0 -> PW_ES_HI + nadm + admInf"),
                         # Infectious asymptomatic
                         paste("@ ->", SPACE ,"? pHI *  prev * rIA : 0 -> PW_IA_HI + nadm + admInf"),
                         # Infectious with mild symptoms
                         paste("@ ->", SPACE ,"? pHI *  prev * rIM : 0 -> PW_IM_HI + nadm + admInf"),
                         # Infectious with severe symptoms
                         paste("@ ->", SPACE ,"? pHI *  prev * rIS : 0 -> PW_IS_HI + nadm + admInf"),
                         ##########
                         ####### Professionals
                         ##########
                         ### Infection
                         ###
                         # pinfH
                         paste("H_S_NI ->  (",nPW,") < 1 ? 0 : H_S_NI *  pconta * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) -> H_E_NI + infH"),
                         paste("H_S_NI_T ->  (",nPW,") < 1 ? 0 : H_S_NI_T *  pconta * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) -> H_E_NI_T + infH"),
                         paste("H_S_LI ->  (", nPW,") < 1 ? 0 : H_S_LI *  pconta * rinfLI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) -> H_E_LI + infH"),
                         paste("H_S_LI_T ->  (", nPW,") < 1 ? 0 : H_S_LI_T *  pconta * rinfLI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) -> H_E_LI_T + infH"),
                         paste("H_S_HI ->  (", nPW,") < 1 ? 0 : H_S_HI *  pconta * rinfHI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) -> H_E_HI + infH"),
                         paste("H_S_HI_T ->  (", nPW,") < 1 ? 0 : H_S_HI_T *  pconta * rinfHI * ((1 - epsPHW) *  ctcHPW * (",
                               nPW,") / (",nH,") * wpropInfPWdest + (1 - epsHHW) * ctcHH * wpropInfHdest) -> H_E_HI_T + infH")
                       )
    )

  return(transitions)

}
