#' Generate global parameters dataset
#'
#' @description
#'
#' @usage build_gdata()
#'
#' @return List of parameters
#'
#' @export

build_gdata <- function(
  ##### Infection
  n_ctcH_PSA = 2,
  t_ctcH_PSA = 10/60/24,
  n_ctcP_PSA = 0,
  t_ctcP_PSA = 5/60/24,
  n_ctcH_PW = 4,
  t_ctcH_PW = 15/60/24,
  n_ctcP_PW = 4,
  t_ctcP_PW = 30/60/24,
  n_ctcH_H = 5,
  t_ctcH_H = 3/60/24,
  t_ctcV_PW = 20/60/24,
  # daily incidence (https://www.gouvernement.fr/info-coronavirus/carte-et-donnees)
  I = 185/100000,
  # disease duration (days)
  d = 10,
  #  basic reproduction number
  R0 = 1.29, # https://www.gouvernement.fr/info-coronavirus/carte-et-donnees
  tSA  = 2/24, # average duration before full admission (in screening area for clinical exam, administrative procedure, etc)
  tISO = 11,   # average duration of confinement (isolated ward or contact restriction)
  tIC  = 15,   # average duration of stay in intensive care
  tSL  = 14,   # average duration of sick leave
  tESL = 28,   # average duration of extended sick leave
  tE  = 5, # duration epidemiological state E
  tEA = 2, # duration epidemiological state EA
  tES = 2, # duration epidemiological state ES
  tIA = 7, # duration epidemiological state IA
  tIM = 8, # duration epidemiological state IM
  tIS = 9, # duration epidemiological state IS
  tLI = 60, # duration of partial immunity before return to non immune status
  tHI = 150, # duration of full immunity before return to partial immune status
  # patient protection
  epsPPSA = 0.1,
  epsHPSA = 0.1,
  epsHPW = 0.1,
  epsPPW = 0.1,
  epsVPW = 0.1,
  # healthcare workers protection
  epsPHSA = 0.1, #from patient in SA
  epsPHW = 0.1, #from patient in W
  epsHHW = 0.1, #from HW in W
  ## Test in ward
  ttestSA = 2/24, # test duration in screening area
  ttestPW = 2/24, # test duration in ward for screening patients
  ttestHW = 2/24, # test duration in ward for screening professionals
  ttestsymp = 2/24, # test duration for symptomatic

  tbtwtestP = 14, # duration between two tests for patient
  tbtwtestH = 30, # duration between two tests for HCWS

  tbeftestPsymp = 2/24, # duration before test of symp patient
  tbeftestHsymp = 1, # duration before test of symp HCWS

  psympNI = 0.5, # probability to be symptomatic when non immune
  psympLI = 0.2, # probability to be symptomatic when partially immune
  psympHI = 0.1, # probability to be symptomatic when fully immune

  psevNI = 0.5, # probability to develop severe symptoms when non immune
  psevLI = 0.3, # probability to develop severe symptoms when partially immune
  psevHI = 0.1, # probability to develop severe symptoms when fully immune

  pISO = 1, # probability to be isolated if confirmed case

  pSL = 0.3, # probability to take sick leave
  pESL = 1, # probability to take extended sick leave
  pSLT = 0.01, # probability to take EL/ESL after positive test

  pIC = 0.3, # probability to be transfer in intensive care
  pdieIC = 0.005, # probability to die in intensive care

  ###################################
  pLI = 0.20, # probability to be PI at the admission (proportion of PI in the population)
  pHI = 0.5, # probability to be FI at the admission (proportion of FI in the population)
  hNI2LI = 1/30, # daily probability to become partially immune
  hLI2HI = 1/60, # daily probability to become fully immune

  rinfLI = 0.7, # partial immunity efficiency % FIX ME better explain that this is the ratio of reduction of probability to be infected compared to non immune
  rinfHI = 0.5, # partial immunity efficiency % FIX ME better explain that this is the ratio of reduction of probability to be infected compared to non immune

  rsymp = 1, # Ratio adjusting probability of symptoms for patients compared to general population (professionals)
  rsev = 1, # Ratio adjusting probability of severity if symptoms for patients compared to general population (professionals)

  ptestPSAsymp = 1, # probability to test symptomatic patients in the screening area
  ptestPSANI = .75,  # probability to test NI patients in the screening area
  ptestPSALI = 0.50, # probability to test PI patients in the screening area
  ptestPSAHI = 0.1, # probability to test FI patients in the screening area

  ptestPWsymp = 0.95, # probability to test symptomatic patients in the ward
  ptestPWNI = 0.75,# probability to test NI patients in the ward
  ptestPWLI = 0.50, # probability to test PI patients in the ward
  ptestPWHI = 0.10, # probability to test FI patients in the ward

  ptestHsymp = 0.85, # probability to test symptomatic HCWS in the ward
  ptestHNI = 0.75, # probability to test NI HCWS
  ptestHLI = 0.50, # probability to test PI HCWS
  ptestHHI = 0.20, # probability to test FI HCWS

  senSA = 0.85,
  speSA = 0.95,
  senW = 0.85,
  speW = 0.95,
  senH = 0.85,
  speH = 0.95,
  sensymp = 0.85,
  spesymp = 0.95
){


  ### Build gdata

  # p = R0 / (dCtc * nCtc * dInf)
  # where
  # p is the probability of transmission per minute spent in contact,
  # dCtc is the average contact duration (in minutes),
  # nCtc is the average number of contacts per person per day, and
  # dInf is the average duration of infectivity (in days): approximately 10 days for COVID-19 [10].

  gdata = c(
    tSA  = tSA, # average duration before full admission (in screening area for clinical exam, administrative procedure, etc)
    tISO = tISO,   # average duration of confinement (isolated ward or contact restriction)
    tIC  = tIC,   # average duration of stay in intensive care
    tSL  = tSL,   # average duration of sick leave
    tESL = tESL,   # average duration of extended sick leave

    tE  = tE, # duration epidemiological state E
    tEA = tEA, # duration epidemiological state EA
    tES = tES, # duration epidemiological state ES
    tIA = tIA, # duration epidemiological state IA
    tIM = tIM, # duration epidemiological state IM
    tIS = tIS, # duration epidemiological state IS

    tLI = tLI, # duration of partial immunity before return to non immune status
    tHI = tHI, # duration of full immunity before return to partial immune status

    ## Contacts
    ctcHPSA = n_ctcH_PSA  * t_ctcH_PSA,
    ctcPPSA = n_ctcP_PSA  * t_ctcP_PSA,

    ctcHPW = n_ctcH_PW  * t_ctcH_PW,
    ctcPPW = n_ctcP_PW  * t_ctcP_PW,
    ctcHH = n_ctcH_H  * t_ctcH_H,

    # n_ctcV_PW => see ldata
    ctcV = t_ctcV_PW,

    # Epsilon
    # patient protection
    epsPPSA = epsPPSA,
    epsHPSA = epsHPSA,
    epsHPW = epsHPW,
    epsPPW = epsPPW,
    epsVPW = epsVPW,

    # healthcare workers protection
    epsPHSA = epsPHSA, #from patient in SA
    epsPHW = epsPHW, #from patient in W
    epsHHW = epsHHW, #from HW in W

    ## Test in ward
    ttestSA = ttestSA, # test duration in screening area
    ttestPW = ttestPW, # test duration in ward for screening of patients
    ttestHW = ttestHW, # test duration in ward for screening of professionals
    ttestsymp = ttestsymp, # test duration for symptomatic

    tbtwtestP = tbtwtestP, # duration between two tests for patient
    tbtwtestH = tbtwtestH, # duration between two tests for HCWS

    tbeftestPsymp = tbeftestPsymp, # duration before test of symp patient
    tbeftestHsymp = tbeftestHsymp, # duration before test of symp HCWS

    # R0
    hinc = I, # daily incidence in the community -- FIX ME: relevant with prev - only input one of both (prev/inc)
    prev = I*d/(1+I*d), # prevalence (probability to be infected at the admission)
    pconta = R0 / (8 * (30/60/24) * d),

    psympNI = psympNI, # probability to be symptomatic when non immune
    psympLI = psympLI, # probability to be symptomatic when partially immune
    psympHI = psympHI, # probability to be symptomatic when fully immune

    psevNI = psevNI, # probability to develop severe symptoms when non immune
    psevLI = psevLI, # probability to develop severe symptoms when partially immune
    psevHI = psevHI, # probability to develop severe symptoms when fully immune

    pISO = pISO,

    pSL = pSL, # probability to take sick leave
    pESL = pESL, # probability to take extended sick leave
    pSLT = pSLT, # probability to take EL/ESL after positive test

    pIC = pIC, # probability to be transfer in intensive care
    pdieIC = pdieIC, # probability to die in intensive care

    ###################################
    pLI = pLI, # probability to be PI at the admission (proportion of PI in the population)
    pHI = pHI, # probability to be FI at the admission (proportion of FI in the population)
    hNI2LI = hNI2LI, # daily probability to become partially immune
    hLI2HI = hLI2HI, # daily probability to become fully immune

    rinfLI = rinfLI, # partial immunity efficiency % FIX ME better explain that this is the ratio of reduction of probability to be infected compared to non immune
    rinfHI = rinfHI, # partial immunity efficiency % FIX ME better explain that this is the ratio of reduction of probability to be infected compared to non immune

    rsymp = rsymp, # Ratio adjusting probability of symptoms for patients compared to general population (professionals)
    rsev = rsev, # Ratio adjusting probability of severity if symptoms for patients compared to general population (professionals)

    ptestPSAsymp = ptestPSAsymp, # probability to test symptomatic patients in the screening area
    ptestPSANI = ptestPSANI,  # probability to test NI patients in the screening area
    ptestPSALI = ptestPSALI, # probability to test PI patients in the screening area
    ptestPSAHI = ptestPSAHI, # probability to test FI patients in the screening area

    ptestPWsymp = ptestPWsymp, # probability to test symptomatic patients in the ward
    ptestPWNI = ptestPWNI,# probability to test NI patients in the ward
    ptestPWLI = ptestPWLI, # probability to test PI patients in the ward
    ptestPWHI = ptestPWHI, # probability to test FI patients in the ward

    ptestHsymp = ptestHsymp, # probability to test symptomatic HCWS in the ward
    ptestHNI = ptestHNI, # probability to test NI HCWS
    ptestHLI = ptestHLI, # probability to test PI HCWS
    ptestHHI = ptestHHI, # probability to test FI HCWS

    senSA = senSA,
    speSA = speSA,
    senW = senW,
    speW = speW,
    senH = senH,
    speH = speH,
    sensymp = sensymp,
    spesymp = spesymp
  )

  # Use psevNI >> worst case scenario
  with(data.frame(gdata %>% t),
       cumd <<- (1 - psympNI) * (tE + tEA + tIA) + psympNI * ((1 - psevNI) * (tE + tES + tIM) + psevNI * (tE + tES + tIS))
  )

  gdata <- c(gdata,
             with(data.frame(gdata %>% t),
                  c(rE = tE/cumd, # time ratio of the epidemiological state E over the whole infectious period (probability to be E at the admission when non susceptible)
                    rEA = (1-psympNI)*(tEA/cumd), # time ratio of the epidemiological state EA over the whole infectious period (probability to be EA at the admission when non susceptible)
                    rES = psympNI*(tES/cumd), # time ratio of the epidemiological state ES over the whole infectious period (probability to be ES at the admission when non susceptible)
                    rIA = (1-psympNI)*(tIA/cumd), # time ratio of the epidemiological state IA over the whole infectious period (probability to be IA at the admission when non susceptible)
                    rIM = psympNI*(1-psevNI)*(tIM/cumd), # time ratio of the epidemiological state IM over the whole infectious period (probability to be IM at the admission when non susceptible)
                    rIS = psympNI*psevNI*(tIS/cumd) # time ratio of the epidemiological state IS over the whole infectious period (probability to be IS at the admission when non susceptible)
                  ))
  )


  return(gdata)

}
